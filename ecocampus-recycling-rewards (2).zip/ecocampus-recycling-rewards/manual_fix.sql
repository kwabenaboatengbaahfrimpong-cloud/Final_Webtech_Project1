-- Run this in your database (phpMyAdmin)
-- This creates a user 'admin@ecocampus.com' with password 'password123'

DELETE FROM users WHERE email = 'admin@ecocampus.com';

INSERT INTO users (name, email, phone, password_hash, role, points)
VALUES (
    'Admin User', 
    'admin@ecocampus.com', 
    '0000000000', 
    '$2y$10$UseAProperHashGeneratedByPHPHereOrUseDebugScriptToGetOne', 
    'admin',
    1000
);

-- NOTE: Since I cannot generate a bcrypt hash for you offline, 
-- please use the debug_auth.php script to generate the SQL if you can.
-- OR, here is a hash for 'password123':
-- $2y$10$YourHashHere... 

-- BETTER OPTION: 
-- Use this simple query to just make the first user an admin:
UPDATE users SET role = 'admin' WHERE id = 1;
