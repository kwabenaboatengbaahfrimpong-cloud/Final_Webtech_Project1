<?php
require_once '../includes/header.php';
require_once '../services/db.php';

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'student') {
    header("Location: " . BASE_URL . "/login.php");
    exit;
}

$success = false;
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $subject = trim($_POST['subject'] ?? '');
    $message = trim($_POST['message'] ?? '');

    if (empty($subject) || empty($message)) {
        $error = "Please fill in all fields.";
    } else {
        try {
            $db->sendSupportMessage($_SESSION['user']['id'], $subject, $message);
            $success = true;
        } catch (Exception $e) {
            $error = "Failed to send message: " . $e->getMessage();
        }
    }
}
?>

<div class="max-w-2xl mx-auto pb-12">
    <div class="mb-8">
        <h1 class="text-3xl font-bold text-gray-800">Need Assistance?</h1>
        <p class="text-gray-500">We're here to help. Send us a message and we'll get back to you.</p>
    </div>

    <?php if ($success): ?>
    <div class="bg-green-50 border border-green-200 text-green-800 rounded-3xl p-8 text-center space-y-4 animate-bounce">
        <div class="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto text-green-600">
            <i data-lucide="check" class="w-8 h-8"></i>
        </div>
        <h2 class="text-2xl font-bold">Message Sent!</h2>
        <p>Thank you for reaching out. Our support team will review your message and respond to your student email within 24 hours.</p>
        <a href="<?= BASE_URL ?>/student/dashboard.php" class="inline-block bg-green-600 text-white px-6 py-3 rounded-xl font-bold hover:bg-green-700 transition mt-4">Return to Dashboard</a>
    </div>
    <?php else: ?>

    <form method="POST" class="bg-white p-8 rounded-[2.5rem] shadow-sm border border-gray-100 space-y-6">
        <?php if ($error): ?>
        <div class="bg-red-50 text-red-600 p-4 rounded-xl border border-red-100 flex items-center gap-3">
             <i data-lucide="alert-circle" class="w-5 h-5"></i>
             <p><?= htmlspecialchars($error) ?></p>
        </div>
        <?php endif; ?>

        <div class="space-y-2">
            <label class="font-bold text-gray-700 ml-1">Subject</label>
            <select name="subject" class="w-full p-4 rounded-xl border border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none transition bg-gray-50">
                <option value="General Inquiry">General Inquiry</option>
                <option value="Issue with Points">Issue with Points</option>
                <option value="Bin Maintenance">Bin Maintenance</option>
                <option value="Reward Redemption">Reward Redemption</option>
                <option value="Other">Other</option>
            </select>
        </div>

        <div class="space-y-2">
            <label class="font-bold text-gray-700 ml-1">Message</label>
            <textarea 
                name="message" 
                rows="6" 
                required
                placeholder="Describe your issue or question..."
                class="w-full p-4 rounded-xl border border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none transition bg-gray-50 resize-none"
            ></textarea>
        </div>

        <button type="submit" class="w-full bg-primary text-white py-4 rounded-2xl font-bold text-lg hover:bg-dark-green transition shadow-lg flex items-center justify-center gap-2">
            <i data-lucide="send" class="w-5 h-5"></i> Send Message
        </button>
    </form>
    <?php endif; ?>
</div>

<?php require_once '../includes/footer.php'; ?>
