<?php
require_once '../config.php';
require_once '../services/db.php';

// Ensure session is started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'student') {
    header("Location: " . BASE_URL . "/login.php");
    exit;
}

$user = $_SESSION['user'];
// Refresh user key
foreach ($db->getUsers() as $u) {
    if ($u['id'] === $user['id']) {
        $user = $u;
        $_SESSION['user'] = $u;
        break;
    }
}

$message = '';
$msgType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $rewardId = $_POST['rewardId'] ?? '';
    if ($rewardId) {
        try {
            $db->redeemReward($user['id'], $rewardId);
            $message = "Success! You redeemed a reward.";
            $msgType = 'success';
            // Refresh user points
             foreach ($db->getUsers() as $u) {
                if ($u['id'] === $user['id']) {
                    $user = $u;
                    $_SESSION['user'] = $u;
                    break;
                }
            }
        } catch (Exception $e) {
            $message = $e->getMessage();
            $msgType = 'error';
        }
    }
}

$rewards = array_filter($db->getRewards(), fn($r) => $r['active']);

require_once '../includes/header.php';
?>

<div class="max-w-7xl mx-auto space-y-8 pb-12">
    <!-- Header -->
    <div class="flex flex-col md:flex-row md:items-center justify-between gap-6">
    <div>
        <h1 class="text-3xl font-bold text-gray-800">Rewards Shop</h1>
        <p class="text-gray-500">Spend your hard-earned points on exclusive campus gear.</p>
    </div>
    <div class="bg-white px-6 py-4 rounded-3xl shadow-sm border border-gray-100 flex items-center gap-4">
        <div class="bg-primary/10 p-2 rounded-full">
        <i data-lucide="star" class="text-primary fill-primary w-6 h-6"></i>
        </div>
        <div>
        <p class="text-xs font-bold text-gray-400 uppercase tracking-widest">My Balance</p>
        <p class="text-2xl font-bold text-gray-800"><?= number_format($user['points']) ?> <span class="text-sm font-medium">pts</span></p>
        </div>
    </div>
    </div>

    <!-- Messages -->
    <?php if ($message): ?>
    <div class="p-4 rounded-2xl flex items-center gap-3 animate-in fade-in zoom-in duration-300 <?= $msgType === 'success' ? 'bg-green-50 text-green-700 border border-green-100' : 'bg-red-50 text-red-700 border border-red-100' ?>">
        <i data-lucide="<?= $msgType === 'success' ? 'check-circle' : 'alert-triangle' ?>" class="w-6 h-6"></i>
        <p class="font-bold"><?= htmlspecialchars($message) ?></p>
    </div>
    <?php endif; ?>

    <!-- Search -->
    <div class="relative max-w-md">
    <i data-lucide="search" class="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5"></i>
    <input 
        type="text"
        id="searchInput"
        placeholder="Search rewards..."
        class="w-full pl-12 pr-4 py-3 rounded-2xl border border-gray-200 outline-none focus:ring-2 focus:ring-primary/20 bg-white shadow-sm transition"
    />
    </div>

    <!-- Rewards Grid -->
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8" id="rewardsGrid">
    <?php foreach ($rewards as $r): 
        $canAfford = $user['points'] >= $r['costPoints'];
        $isOutOfStock = $r['stock'] <= 0;
    ?>
    <div class="reward-card h-full bg-white rounded-[2rem] shadow-sm border border-gray-100 overflow-hidden flex flex-col group hover:shadow-xl transition-all duration-300" data-name="<?= strtolower($r['name']) ?>" data-desc="<?= strtolower($r['description']) ?>">
        <div class="relative aspect-[4/3] overflow-hidden">
        <img 
            src="<?= !empty($r['image']) ? BASE_URL . htmlspecialchars($r['image']) : BASE_URL . "/assets/images/default-reward.png" ?>" 
            alt="<?= htmlspecialchars($r['name']) ?>" 
            class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
        />
        <div class="absolute top-4 right-4 bg-white/90 backdrop-blur-sm px-4 py-1.5 rounded-full shadow-sm">
            <p class="text-primary font-bold text-sm"><?= $r['costPoints'] ?> pts</p>
        </div>
        <?php if (!$canAfford && !$isOutOfStock): ?>
            <div class="absolute inset-0 bg-gray-900/40 backdrop-blur-[2px] flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
            <div class="bg-white px-4 py-2 rounded-xl text-xs font-bold text-gray-800 flex items-center gap-2">
                Need <?= $r['costPoints'] - $user['points'] ?> more points
            </div>
            </div>
        <?php endif; ?>
        <?php if ($isOutOfStock): ?>
            <div class="absolute inset-0 bg-red-900/20 backdrop-blur-[2px] flex items-center justify-center">
            <div class="bg-red-600 text-white px-6 py-2 rounded-xl text-sm font-bold shadow-lg">
                Out of Stock
            </div>
            </div>
        <?php endif; ?>
        </div>
        <div class="p-6 flex-1 flex flex-col">
        <h3 class="text-xl font-bold text-gray-800 mb-2"><?= htmlspecialchars($r['name']) ?></h3>
        <p class="text-gray-500 text-sm line-clamp-2 mb-6 flex-1"><?= htmlspecialchars($r['description']) ?></p>
        
        <div class="flex items-center justify-between mb-4">
            <div class="flex items-center gap-1.5 text-xs font-bold text-gray-400 uppercase tracking-widest">
            <i data-lucide="package" class="w-4 h-4"></i> <?= $r['stock'] ?> Remaining
            </div>
        </div>

        <form method="POST">
            <input type="hidden" name="rewardId" value="<?= $r['id'] ?>">
            <button
                type="submit"
                <?= (!$canAfford || $isOutOfStock) ? 'disabled' : '' ?>
                class="w-full py-4 rounded-2xl font-bold transition flex items-center justify-center gap-2 
                <?= ($isOutOfStock || !$canAfford) ? 'bg-gray-100 text-gray-400 cursor-not-allowed' : 'bg-primary text-white hover:bg-dark-green shadow-lg shadow-primary/20' ?>"
                onclick="return confirm('Are you sure you want to redeem this reward?')"
            >
                <i data-lucide="shopping-bag" class="w-5 h-5"></i> Redeem
            </button>
        </form>
        </div>
    </div>
    <?php endforeach; ?>
    </div>
</div>

<script>
    const searchInput = document.getElementById('searchInput');
    const cards = document.querySelectorAll('.reward-card');
    
    searchInput.addEventListener('input', (e) => {
        const val = e.target.value.toLowerCase();
        cards.forEach(card => {
            const name = card.getAttribute('data-name');
            const desc = card.getAttribute('data-desc');
            if (name.includes(val) || desc.includes(val)) {
                card.style.display = 'flex';
            } else {
                card.style.display = 'none';
            }
        });
    });
</script>

<?php require_once '../includes/footer.php'; ?>
