<?php
require_once '../includes/header.php';
require_once '../services/db.php';

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'student') {
    header("Location: " . BASE_URL . "/login.php");
    exit;
}

$user = $_SESSION['user'];
$users = array_filter($db->getUsers(), fn($u) => $u['role'] === 'student');
usort($users, fn($a, $b) => $b['points'] - $a['points']);
$topUsers = array_slice($users, 0, 20);

// Find my rank
$myRank = 0;
foreach ($users as $index => $u) {
    if ($u['id'] === $user['id']) {
        $myRank = $index + 1;
        break;
    }
}
?>

<div class="max-w-7xl mx-auto space-y-8 pb-12">
    <div class="flex flex-col md:flex-row md:items-center justify-between gap-6">
    <div>
        <h1 class="text-3xl font-bold text-gray-800">Recycling Leaderboard</h1>
        <p class="text-gray-500">Celebrating our campus sustainability champions.</p>
    </div>
    <div class="bg-primary text-white px-8 py-6 rounded-[2rem] shadow-xl flex items-center gap-6">
        <div class="bg-white/20 p-4 rounded-2xl">
        <i data-lucide="trophy" class="w-8 h-8"></i>
        </div>
        <div>
        <p class="text-xs font-bold uppercase tracking-widest text-white/70">Your Ranking</p>
        <p class="text-3xl font-bold">#<?= $myRank > 0 ? $myRank : '20+' ?></p>
        </div>
    </div>
    </div>

    <div class="grid lg:grid-cols-3 gap-8">
    <!-- Main Leaderboard -->
    <div class="lg:col-span-2 space-y-4">
        <div class="bg-white rounded-[2.5rem] shadow-sm border border-gray-100 overflow-hidden">
        <div class="p-8 border-b border-gray-50 flex justify-between items-center">
            <h2 class="text-xl font-bold text-gray-800">Top 20 Recyclers</h2>
            <div class="text-xs font-bold text-primary bg-light-green px-3 py-1 rounded-full uppercase tracking-widest">
            Updates Monthly
            </div>
        </div>
        
        <div class="overflow-x-auto">
            <table class="w-full text-left">
            <thead class="bg-gray-50/50 text-gray-400 text-[10px] font-bold uppercase tracking-[0.2em]">
                <tr>
                <th class="px-8 py-4">Rank</th>
                <th class="px-8 py-4">Student</th>
                <th class="px-8 py-4 text-right">Points</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-50">
                <?php foreach ($topUsers as $index => $u): 
                $rank = $index + 1;
                $isMe = $u['id'] === $user['id'];
                ?>
                <tr class="<?= $isMe ? 'bg-light-green/40' : 'hover:bg-gray-50' ?> transition">
                    <td class="px-8 py-6">
                    <div class="flex items-center justify-center w-8 h-8 rounded-full font-bold text-sm">
                        <?php if ($rank === 1): ?>
                        <i data-lucide="crown" class="text-yellow-500 w-6 h-6"></i>
                        <?php elseif ($rank === 2): ?>
                        <i data-lucide="medal" class="text-gray-400 w-6 h-6"></i>
                        <?php elseif ($rank === 3): ?>
                        <i data-lucide="medal" class="text-amber-600 w-6 h-6"></i>
                        <?php else: ?>
                        <span class="text-gray-400"><?= $rank ?></span>
                        <?php endif; ?>
                    </div>
                    </td>
                    <td class="px-8 py-6">
                    <div class="flex items-center gap-4">
                        <div class="w-10 h-10 rounded-2xl flex items-center justify-center font-bold text-white shadow-sm 
                        <?= $rank === 1 ? 'bg-yellow-500' : ($rank === 2 ? 'bg-gray-300' : ($rank === 3 ? 'bg-amber-600' : 'bg-primary/20 text-primary')) ?>">
                        <?= strtoupper(substr($u['name'], 0, 1)) ?>
                        </div>
                        <div>
                        <p class="font-bold text-sm <?= $isMe ? 'text-primary' : 'text-gray-800' ?>">
                            <?= htmlspecialchars($u['name']) ?> 
                            <?php if ($isMe): ?>
                            <span class="ml-2 text-[10px] bg-primary text-white px-2 py-0.5 rounded-full">YOU</span>
                            <?php endif; ?>
                        </p>
                        <p class="text-xs text-gray-500">Joined <?= $u['created_at'] ? date('n/j/Y', strtotime($u['created_at'])) : date('n/j/Y') ?></p>
                        </div>
                    </div>
                    </td>
                    <td class="px-8 py-6 text-right font-bold text-gray-800">
                    <?= number_format($u['points']) ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
            </table>
        </div>
        </div>
    </div>

    <!-- Sidebar Info -->
    <div class="space-y-6">
        <div class="bg-[#a98467] rounded-[2rem] p-8 text-white shadow-xl relative overflow-hidden group">
        <i data-lucide="trending-up" class="absolute -bottom-4 -right-4 w-32 h-32 text-white/5 rotate-12"></i>
        <h3 class="text-xl font-bold mb-4 flex items-center gap-2">
            <i data-lucide="star" class="text-yellow-300 fill-yellow-300 w-5 h-5"></i> How it works
        </h3>
        <div class="space-y-4 text-white/90 text-sm">
            <div class="flex gap-3">
            <div class="w-6 h-6 rounded-full bg-white/20 flex items-center justify-center text-xs font-bold text-white flex-shrink-0">1</div>
            <p>Only <span class="text-white font-bold underline decoration-white/30 underline-offset-4">Approved</span> submissions count towards your points.</p>
            </div>
            <div class="flex gap-3">
            <div class="w-6 h-6 rounded-full bg-white/20 flex items-center justify-center text-xs font-bold text-white flex-shrink-0">2</div>
            <p>Points earned from materials like <span class="text-white font-bold">E-waste</span> give you the fastest climb.</p>
            </div>
            <div class="flex gap-3">
            <div class="w-6 h-6 rounded-full bg-white/20 flex items-center justify-center text-xs font-bold text-white flex-shrink-0">3</div>
            <p>Top 10 finishers each month receive a <span class="text-white font-bold">Bonus Reward Pack</span>.</p>
            </div>
        </div>
        <a href="<?= BASE_URL ?>/student/rewards.php" class="mt-8 w-full bg-white text-primary py-4 rounded-2xl font-bold hover:bg-light-green transition flex items-center justify-center gap-2 group shadow-lg">
            View Prizes <i data-lucide="chevron-right" class="w-4 h-4 group-hover:translate-x-1 transition"></i>
        </a>
        </div>

        <div class="bg-white p-8 rounded-[2rem] shadow-sm border border-gray-100">
        <h3 class="text-lg font-bold text-gray-800 mb-4 flex items-center gap-2">
            <i data-lucide="info" class="w-5 h-5 text-primary"></i> Reset Schedule
        </h3>
        <p class="text-sm text-gray-500 leading-relaxed">
            The leaderboard resets at 12:00 AM on the <span class="font-bold text-gray-800">1st of every month</span>. Be sure to submit all your recycling before the month ends to secure your rank!
        </p>
        </div>
    </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
