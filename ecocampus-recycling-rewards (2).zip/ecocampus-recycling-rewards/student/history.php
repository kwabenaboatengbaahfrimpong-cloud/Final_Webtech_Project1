<?php
require_once '../includes/header.php';
require_once '../services/db.php';

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'student') {
    header("Location: " . BASE_URL . "/login.php");
    exit;
}

$user = $_SESSION['user'];
$submissions = array_filter($db->getSubmissions(), fn($s) => $s['userId'] === $user['id']);
$redemptions = array_filter($db->getRedemptions(), fn($s) => $s['userId'] === $user['id']);
?>

<div class="max-w-7xl mx-auto space-y-8 pb-12">
    <div class="flex flex-col md:flex-row md:items-center justify-between gap-6">
    <div>
        <h1 class="text-3xl font-bold text-gray-800">My Activity History</h1>
        <p class="text-gray-500">Track all your contributions and rewards in one place.</p>
    </div>
    <div class="flex p-1.5 bg-white rounded-2xl shadow-sm border border-gray-100">
        <button 
        onclick="switchTab('recycling')"
        id="tab-recycling"
        class="px-6 py-2.5 rounded-xl text-sm font-bold transition-all bg-primary text-white shadow-lg"
        >
        Recycling Logs
        </button>
        <button 
        onclick="switchTab('rewards')"
        id="tab-rewards"
        class="px-6 py-2.5 rounded-xl text-sm font-bold transition-all text-gray-500 hover:text-primary"
        >
        Redemptions
        </button>
    </div>
    </div>

    <div class="bg-white rounded-[2.5rem] shadow-sm border border-gray-100 overflow-hidden">
    <!-- Recycling Tab -->
    <div id="content-recycling" class="overflow-x-auto">
        <table class="w-full text-left">
        <thead class="bg-gray-50/50 text-gray-400 text-[10px] font-bold uppercase tracking-[0.2em] border-b border-gray-50">
            <tr>
            <th class="px-8 py-4">Submission Date</th>
            <th class="px-8 py-4">Material & Bin</th>
            <th class="px-8 py-4">Weight (KG)</th>
            <th class="px-8 py-4">Status</th>
            <th class="px-8 py-4 text-right">Points</th>
            </tr>
        </thead>
        <tbody class="divide-y divide-gray-50">
            <?php foreach ($submissions as $s): ?>
            <tr class="hover:bg-gray-50 transition">
                <td class="px-8 py-6">
                <div class="flex items-center gap-3">
                    <i data-lucide="clock" class="w-4 h-4 text-gray-300"></i>
                    <span class="font-medium text-gray-600"><?= date('n/j/Y', strtotime($s['createdAt'])) ?></span>
                </div>
                </td>
                <td class="px-8 py-6">
                <div class="font-bold text-gray-800"><?= htmlspecialchars($s['materialName']) ?></div>
                <div class="text-xs text-gray-500"><?= htmlspecialchars($s['binName']) ?></div>
                </td>
                <td class="px-8 py-6 font-bold text-gray-700"><?= $s['weightKg'] ?>kg</td>
                <td class="px-8 py-6">
                <div class="flex flex-col">
                    <span class="w-fit px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest 
                    <?= $s['status'] === 'approved' ? 'bg-green-100 text-green-600' : ($s['status'] === 'rejected' ? 'bg-red-100 text-red-600' : 'bg-orange-100 text-orange-600') ?>">
                    <?= $s['status'] ?>
                    </span>
                    <?php if (isset($s['adminNotes']) && $s['adminNotes']): ?>
                    <span class="text-[10px] text-gray-400 italic mt-1 max-w-[150px] truncate">"<?= htmlspecialchars($s['adminNotes']) ?>"</span>
                    <?php endif; ?>
                </div>
                </td>
                <td class="px-8 py-6 text-right font-bold text-primary">
                <?= $s['status'] === 'approved' ? "+{$s['pointsAwarded']}" : '—' ?>
                </td>
            </tr>
            <?php endforeach; ?>
            <?php if (empty($submissions)): ?>
            <tr>
                <td colspan="5" class="p-20 text-center text-gray-400">
                <i data-lucide="recycle" class="w-16 h-16 mx-auto mb-4 opacity-10"></i>
                <p>No recycling logs found.</p>
                </td>
            </tr>
            <?php endif; ?>
        </tbody>
        </table>
    </div>

    <!-- Rewards Tab -->
    <div id="content-rewards" class="overflow-x-auto hidden">
        <table class="w-full text-left">
        <thead class="bg-gray-50/50 text-gray-400 text-[10px] font-bold uppercase tracking-[0.2em] border-b border-gray-50">
            <tr>
            <th class="px-8 py-4">Request Date</th>
            <th class="px-8 py-4">Reward Name</th>
            <th class="px-8 py-4">Status</th>
            <th class="px-8 py-4 text-right">Points Cost</th>
            </tr>
        </thead>
        <tbody class="divide-y divide-gray-50">
            <?php foreach ($redemptions as $r): ?>
            <tr class="hover:bg-gray-50 transition">
                <td class="px-8 py-6">
                <span class="font-medium text-gray-600"><?= date('n/j/Y', strtotime($r['createdAt'])) ?></span>
                </td>
                <td class="px-8 py-6">
                <div class="flex items-center gap-3">
                    <i data-lucide="package" class="w-5 h-5 text-primary"></i>
                    <span class="font-bold text-gray-800"><?= htmlspecialchars($r['rewardName']) ?></span>
                </div>
                </td>
                <td class="px-8 py-6">
                <span class="px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest 
                    <?= $r['status'] === 'fulfilled' ? 'bg-green-100 text-green-600' : ($r['status'] === 'cancelled' ? 'bg-red-100 text-red-600' : 'bg-orange-100 text-orange-600') ?>">
                    <?= $r['status'] ?>
                </span>
                </td>
                <td class="px-8 py-6 text-right font-bold text-orange-500">
                -<?= $r['pointsCost'] ?>
                </td>
            </tr>
            <?php endforeach; ?>
            <?php if (empty($redemptions)): ?>
            <tr>
                <td colspan="4" class="p-20 text-center text-gray-400">
                <i data-lucide="gift" class="w-16 h-16 mx-auto mb-4 opacity-10"></i>
                <p>No redemption history found.</p>
                </td>
            </tr>
            <?php endif; ?>
        </tbody>
        </table>
    </div>
    </div>

    <!-- Support Banner -->
    <div class="bg-light-green p-8 rounded-[2.5rem] border border-primary/10 flex flex-col md:flex-row items-center justify-between gap-6">
    <div class="flex items-center gap-6">
        <div class="bg-white p-4 rounded-3xl shadow-sm text-primary">
        <i data-lucide="package" class="w-10 h-10"></i>
        </div>
        <div>
        <h4 class="text-lg font-bold text-gray-800">Need some assistance?</h4>
        <p class="text-gray-500 text-sm max-w-sm">Chat with our AI sustainability assistant for help with rewards, recycling tips, or account issues.</p>
        </div>
    </div>
    <button 
        onclick="toggleSupport()"
        class="bg-primary text-white px-8 py-4 rounded-2xl font-bold hover:bg-dark-green shadow-xl transition whitespace-nowrap flex items-center gap-2"
    >
        <i data-lucide="message-circle" class="w-5 h-5"></i> Contact Support
    </button>
    </div>

    <!-- Support Modal (Simple Mock) -->
    <div id="supportModal" class="hidden fixed inset-0 z-[60] flex items-center justify-center p-4 bg-gray-900/40 backdrop-blur-sm">
        <div class="bg-white w-full max-w-lg rounded-[2.5rem] shadow-2xl overflow-hidden flex flex-col h-[600px]">
            <div class="p-6 bg-primary text-white flex justify-between items-center">
            <div class="flex items-center gap-3">
                <div class="bg-white/20 p-2 rounded-xl">
                <i data-lucide="bot" class="w-6 h-6"></i>
                </div>
                <div>
                <h2 class="text-xl font-bold">EcoSupport AI</h2>
                <p class="text-xs text-white/70">Online & Ready to Help</p>
                </div>
            </div>
            <button onclick="toggleSupport()" class="hover:rotate-90 transition-transform p-1">
                <i data-lucide="x" class="w-8 h-8"></i>
            </button>
            </div>
            <div class="flex-1 p-6 flex flex-col items-center justify-center text-center space-y-4">
                <i data-lucide="bot" class="w-16 h-16 text-primary opacity-20"></i>
                <p class="text-gray-500">The chat feature is currently being upgraded.</p>
                <p class="text-xs text-gray-400">Please contact support@ecocampus.com for urgent inquiries.</p>
            </div>
        </div>
    </div>
</div>

<script>
    function switchTab(tab) {
        const recyclingContent = document.getElementById('content-recycling');
        const rewardsContent = document.getElementById('content-rewards');
        const recyclingTab = document.getElementById('tab-recycling');
        const rewardsTab = document.getElementById('tab-rewards');

        if (tab === 'recycling') {
            recyclingContent.classList.remove('hidden');
            rewardsContent.classList.add('hidden');
            recyclingTab.className = 'px-6 py-2.5 rounded-xl text-sm font-bold transition-all bg-primary text-white shadow-lg';
            rewardsTab.className = 'px-6 py-2.5 rounded-xl text-sm font-bold transition-all text-gray-500 hover:text-primary';
        } else {
            recyclingContent.classList.add('hidden');
            rewardsContent.classList.remove('hidden');
            recyclingTab.className = 'px-6 py-2.5 rounded-xl text-sm font-bold transition-all text-gray-500 hover:text-primary';
            rewardsTab.className = 'px-6 py-2.5 rounded-xl text-sm font-bold transition-all bg-primary text-white shadow-lg';
        }
    }

    function toggleSupport() {
        const modal = document.getElementById('supportModal');
        modal.classList.toggle('hidden');
    }
</script>

<?php require_once '../includes/footer.php'; ?>
