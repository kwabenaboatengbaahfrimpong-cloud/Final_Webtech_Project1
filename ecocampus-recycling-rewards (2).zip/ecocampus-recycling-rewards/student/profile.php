<?php
require_once '../config.php';
require_once '../services/db.php';

// Ensure session is started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'student') {
    header("Location: " . BASE_URL . "/login.php");
    exit;
}

$user = $_SESSION['user'];

// Refresh user data
foreach ($db->getUsers() as $u) {
    if ($u['id'] === $user['id']) {
        $user = $u;
        $_SESSION['user'] = $u; // Update session with fresh data
        break;
    }
}

// Handle Profile Update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'] ?? '';
    $phone = $_POST['phone'] ?? '';
    if ($name) {
        $db->updateProfile($user['id'], $name, $phone);
        // Refresh session
        $_SESSION['user']['name'] = $name;
        $_SESSION['user']['phone'] = $phone;
        header("Location: profile.php?success=1");
        exit;
    }
}

$submissions = array_filter($db->getSubmissions(), fn($s) => $s['userId'] === $user['id']);
$approved = count(array_filter($submissions, fn($s) => $s['status'] === 'approved'));
$rate = count($submissions) > 0 ? number_format(($approved / count($submissions)) * 100, 0) : 0;

require_once '../includes/header.php';
?>

<div class="max-w-4xl mx-auto space-y-8 pb-12">
    <h1 class="text-3xl font-bold text-gray-800">My Profile</h1>
    
    <div class="bg-white rounded-[2.5rem] shadow-sm border border-gray-100 overflow-hidden">
    <div class="bg-primary h-32 relative">
        <div class="absolute -bottom-12 left-12 w-24 h-24 bg-white rounded-[2rem] shadow-xl p-1">
        <div class="bg-light-green w-full h-full rounded-[1.8rem] flex items-center justify-center text-primary text-3xl font-bold">
            <?= strtoupper(substr($user['name'], 0, 1)) ?>
        </div>
        </div>
    </div>
    
    <div class="pt-16 px-12 pb-12">
        <div class="flex justify-between items-start mb-8">
        <div>
            <h2 class="text-3xl font-bold text-gray-800"><?= htmlspecialchars($user['name']) ?></h2>
            <p class="text-gray-500 font-medium"><?= htmlspecialchars($user['email']) ?></p>
        </div>
        <a href="?edit=true" class="px-6 py-2 border border-gray-200 rounded-xl font-bold text-gray-600 hover:bg-gray-50 transition flex items-center gap-2">
            <i data-lucide="pencil" class="w-5 h-5"></i> Edit Profile
        </a>
        </div>

        <div class="grid grid-cols-2 md:grid-cols-4 gap-6">
        <div class="p-6 bg-gray-50 rounded-3xl">
            <p class="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Total Points</p>
            <p class="text-2xl font-bold text-primary"><?= number_format($user['points']) ?></p>
        </div>
        <div class="p-6 bg-gray-50 rounded-3xl">
            <p class="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Submissions</p>
            <p class="text-2xl font-bold text-gray-800"><?= count($submissions) ?></p>
        </div>
        <div class="p-6 bg-gray-50 rounded-3xl">
            <p class="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Approved</p>
            <p class="text-2xl font-bold text-green-600"><?= $approved ?></p>
        </div>
        <div class="p-6 bg-gray-50 rounded-3xl">
            <p class="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Accuracy</p>
            <p class="text-2xl font-bold text-blue-600"><?= $rate ?>%</p>
        </div>
        </div>

        <div class="mt-12 space-y-6">
        <h3 class="text-xl font-bold text-gray-800 mb-6">Account Details</h3>
        
        <?php if (isset($_GET['edit'])): ?>
            <form method="POST" class="bg-gray-50 rounded-[2rem] p-8 space-y-6">
                 <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <label class="block space-y-2">
                        <span class="text-xs font-bold text-gray-400 uppercase tracking-widest">Full Name</span>
                        <input type="text" name="name" value="<?= htmlspecialchars($user['name']) ?>" class="w-full p-4 rounded-xl border border-gray-200 outline-none focus:border-primary focus:ring-2 focus:ring-primary/10 transition" required>
                    </label>
                    <label class="block space-y-2">
                        <span class="text-xs font-bold text-gray-400 uppercase tracking-widest">Phone Number</span>
                        <input type="tel" name="phone" value="<?= htmlspecialchars($user['phone'] ?? '') ?>" class="w-full p-4 rounded-xl border border-gray-200 outline-none focus:border-primary focus:ring-2 focus:ring-primary/10 transition" placeholder="+1234567890">
                    </label>
                 </div>
                 
                 <div class="flex items-center gap-4 pt-4">
                     <button type="submit" class="bg-primary text-white px-8 py-3 rounded-xl font-bold hover:bg-dark-green transition shadow-lg shadow-primary/20">
                         Save Changes
                     </button>
                     <a href="profile.php" class="text-gray-500 font-bold hover:text-gray-700 transition">Cancel</a>
                 </div>
            </form>
        <?php else: ?>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div class="space-y-4">
            <div class="flex justify-between items-center py-4 border-b border-gray-50">
                <span class="text-sm font-bold text-gray-400 uppercase tracking-widest">Phone</span>
                <span class="text-gray-800 font-medium"><?= htmlspecialchars($user['phone'] ?? 'Not provided') ?></span>
            </div>
            <div class="flex justify-between items-center py-4 border-b border-gray-50">
                <span class="text-sm font-bold text-gray-400 uppercase tracking-widest">Role</span>
                <span class="text-gray-800 font-medium capitalize"><?= htmlspecialchars($user['role']) ?></span>
            </div>
            </div>
            <div class="space-y-4">
            <div class="flex justify-between items-center py-4 border-b border-gray-50">
                <span class="text-sm font-bold text-gray-400 uppercase tracking-widest">Member Since</span>
                <span class="text-gray-800 font-medium"><?= $user['created_at'] ? date('n/j/Y', strtotime($user['created_at'])) : date('n/j/Y') ?></span>
            </div>
            <div class="flex justify-between items-center py-4 border-b border-gray-50">
                <span class="text-sm font-bold text-gray-400 uppercase tracking-widest">Status</span>
                <span class="text-green-600 font-bold">Active Account</span>
            </div>
            </div>
        </div>
        <?php endif; ?>
        </div>
    </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
