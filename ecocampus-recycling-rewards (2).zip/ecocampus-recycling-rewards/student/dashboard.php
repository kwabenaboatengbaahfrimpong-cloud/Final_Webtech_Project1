<?php
require_once '../includes/header.php';
require_once '../services/db.php';

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'student') {
    header("Location: " . BASE_URL . "/login.php");
    exit;
}

$user = $_SESSION['user'];
// Refresh user data from DB
foreach ($db->getUsers() as $u) {
    if ($u['id'] === $user['id']) {
        $user = $u;
        $_SESSION['user'] = $u;
        break;
    }
}

$submissions = array_filter($db->getSubmissions(), function($s) use ($user) {
    return $s['userId'] === $user['id'];
});
$redemptions = array_filter($db->getRedemptions(), function($s) use ($user) {
    return $s['userId'] === $user['id'];
});

// Slice for recent
$recentSubmissions = array_slice($submissions, 0, 5);
$recentRedemptions = array_slice($redemptions, 0, 5);

$approvedCount = count(array_filter($submissions, fn($s) => $s['status'] === 'approved'));
$pendingCount = count(array_filter($submissions, fn($s) => $s['status'] === 'pending'));

$tips = [
    "Recycle more to earn more points and help the planet!",
    "Every piece of plastic you recycle saves energy.",
    "Rinse your containers before recycling to avoid contamination.",
    "Cardboard boxes should be flattened before recycling.",
    "Glass can be recycled endlessly without losing quality."
];
$ecoTip = $tips[array_rand($tips)];

?>

<div class="max-w-7xl mx-auto space-y-8 pb-12">
    <!-- Header -->
    <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
    <div>
        <h1 class="text-3xl font-bold text-gray-800">Hello, <?= htmlspecialchars($user['name']) ?>! 👋</h1>
        <p class="text-gray-500 mt-1">Ready to make a difference today?</p>
    </div>
    <a href="<?= BASE_URL ?>/student/submit.php" class="bg-primary text-white px-6 py-3 rounded-2xl font-bold hover:bg-dark-green transition shadow-lg flex items-center gap-2 w-fit">
        <i data-lucide="recycle" class="w-5 h-5"></i> Log New Recycling
    </a>
    </div>

    <!-- Stats Cards -->
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
    <div class="bg-white p-6 rounded-3xl shadow-sm border border-gray-100 flex flex-col items-center text-center relative overflow-hidden group">
        <div class="absolute top-0 right-0 w-24 h-24 bg-primary/5 rounded-bl-full -mr-12 -mt-12 transition-all group-hover:scale-110"></div>
        <div class="bg-primary/10 p-4 rounded-2xl text-primary mb-4">
        <i data-lucide="star" class="w-8 h-8 fill-primary"></i>
        </div>
        <p class="text-3xl font-bold text-gray-800"><?= number_format($user['points']) ?></p>
        <p class="text-sm font-bold text-gray-400 uppercase tracking-widest mt-1">Total Points</p>
    </div>

    <div class="bg-white p-6 rounded-3xl shadow-sm border border-gray-100 flex flex-col items-center text-center">
        <div class="bg-blue-50 p-4 rounded-2xl text-blue-500 mb-4">
        <i data-lucide="check-circle" class="w-8 h-8"></i>
        </div>
        <p class="text-3xl font-bold text-gray-800"><?= $approvedCount ?></p>
        <p class="text-sm font-bold text-gray-400 uppercase tracking-widest mt-1">Approved Logs</p>
    </div>

    <div class="bg-white p-6 rounded-3xl shadow-sm border border-gray-100 flex flex-col items-center text-center">
        <div class="bg-orange-50 p-4 rounded-2xl text-orange-500 mb-4">
        <i data-lucide="clock" class="w-8 h-8"></i>
        </div>
        <p class="text-3xl font-bold text-gray-800"><?= $pendingCount ?></p>
        <p class="text-sm font-bold text-gray-400 uppercase tracking-widest mt-1">Pending Review</p>
    </div>

    <div class="bg-primary p-6 rounded-3xl shadow-xl border border-primary text-white flex flex-col items-center text-center relative group cursor-default">
        <i data-lucide="sparkles" class="absolute top-4 right-4 w-6 h-6 text-white/40 group-hover:rotate-12 transition-transform"></i>
        <div class="bg-white/20 p-4 rounded-2xl mb-4">
        <i data-lucide="trending-up" class="w-8 h-8"></i>
        </div>
        <p class="text-xl font-bold leading-tight">Elite Recycler</p>
        <p class="text-sm text-white/80 mt-1">Keep it up!</p>
    </div>
    </div>

    <!-- AI Sustainability Tip -->
    <!-- AI Sustainability Ticker -->
    <div class="bg-[#a98467] rounded-[2rem] py-4 text-white shadow-xl overflow-hidden relative flex items-center">
        <div class="absolute left-0 top-0 bottom-0 bg-[#a98467] z-10 px-6 flex items-center shadow-[5px_0_20px_rgba(0,0,0,0.1)]">
            <div class="bg-white/20 p-2 rounded-xl">
                 <i data-lucide="sparkles" class="w-6 h-6"></i>
            </div>
            <span class="font-bold ml-3 text-sm uppercase tracking-widest whitespace-nowrap">Fun Fact</span>
        </div>
        
        <div class="ticker-wrapper flex items-center whitespace-nowrap">
            <div class="ticker-content flex items-center gap-12 pl-[240px]">
                <span class="text-lg font-medium opacity-90">Did you know? Recycling one aluminum can saves enough energy to run a TV!</span>
                <i data-lucide="circle" class="w-2 h-2 opacity-40 fill-current"></i>
                <span class="text-lg font-medium opacity-90">Glass is 100% recyclable and can be recycled endlessly without loss in quality or purity.</span>
                <i data-lucide="circle" class="w-2 h-2 opacity-40 fill-current"></i>
                <span class="text-lg font-medium opacity-90">Recycling a single plastic bottle can conserve enough energy to light a light bulb.</span>
            </div>
             <!-- Duplicate for infinite scroll -->
             <div class="ticker-content flex items-center gap-12">
                <span class="text-lg font-medium opacity-90">Did you know? Recycling one aluminum can saves enough energy to run a TV!</span>
                <i data-lucide="circle" class="w-2 h-2 opacity-40 fill-current"></i>
                <span class="text-lg font-medium opacity-90">Glass is 100% recyclable and can be recycled endlessly without loss in quality or purity.</span>
                <i data-lucide="circle" class="w-2 h-2 opacity-40 fill-current"></i>
                <span class="text-lg font-medium opacity-90">Recycling a single plastic bottle can conserve enough energy to light a light bulb.</span>
            </div>
        </div>
    </div>

    <style>
        .ticker-wrapper {
            animation: ticker 30s linear infinite;
        }
        @keyframes ticker {
            0% { transform: translateX(0); }
            100% { transform: translateX(-50%); }
        }
        /* Pause on hover */
        .ticker-wrapper:hover {
            animation-play-state: paused;
        }
    </style>

    <div class="grid lg:grid-cols-3 gap-8">
    <!-- Recent Submissions -->
    <div class="lg:col-span-2 space-y-4">
        <div class="flex justify-between items-center px-2">
        <h2 class="text-xl font-bold text-gray-800 flex items-center gap-2">
            <i data-lucide="clock" class="w-5 h-5 text-primary"></i> Recent Recycling
        </h2>
        <a href="<?= BASE_URL ?>/student/history.php" class="text-primary font-bold text-sm hover:underline flex items-center gap-1">
            View All <i data-lucide="chevron-right" class="w-4 h-4"></i>
        </a>
        </div>

        <div class="bg-white rounded-3xl shadow-sm border border-gray-100 overflow-hidden">
        <?php if (count($recentSubmissions) > 0): ?>
            <table class="w-full text-left">
            <thead class="bg-gray-50 text-gray-500 text-xs font-bold uppercase tracking-wider border-b border-gray-100">
                <tr>
                <th class="px-6 py-4">Material</th>
                <th class="px-6 py-4">Weight (Kg)</th>
                <th class="px-6 py-4">Status</th>
                <th class="px-6 py-4 text-right">Points</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-50">
                <?php foreach ($recentSubmissions as $s): ?>
                <tr class="hover:bg-gray-50 transition">
                    <td class="px-6 py-4">
                    <div class="font-bold text-gray-800"><?= htmlspecialchars($s['materialName']) ?></div>
                    <div class="text-xs text-gray-500"><?= htmlspecialchars($s['binName']) ?></div>
                    </td>
                    <td class="px-6 py-4 font-medium text-gray-600"><?= number_format($s['weightKg'], 1) ?></td>
                    <td class="px-6 py-4">
                    <span class="px-3 py-1 rounded-full text-xs font-bold uppercase tracking-widest
                        <?= $s['status'] === 'approved' ? 'bg-green-100 text-green-600' :
                           ($s['status'] === 'rejected' ? 'bg-red-100 text-red-600' : 'bg-orange-100 text-orange-600') ?>">
                        <?= htmlspecialchars($s['status']) ?>
                    </span>
                    </td>
                    <td class="px-6 py-4 text-right font-bold text-primary">+<?= $s['pointsAwarded'] ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
            </table>
        <?php else: ?>
            <div class="p-12 text-center text-gray-500">
            <i data-lucide="recycle" class="w-12 h-12 mx-auto mb-4 opacity-20"></i>
            <p>No submissions yet. Start recycling today!</p>
            </div>
        <?php endif; ?>
        </div>
    </div>

    <!-- Quick Rewards -->
    <div class="space-y-4">
        <div class="flex justify-between items-center px-2">
        <h2 class="text-xl font-bold text-gray-800 flex items-center gap-2">
            <i data-lucide="gift" class="w-5 h-5 text-primary"></i> Rewards Redeemed
        </h2>
        <a href="<?= BASE_URL ?>/student/rewards.php" class="text-primary font-bold text-sm hover:underline flex items-center gap-1">
            Store <i data-lucide="chevron-right" class="w-4 h-4"></i>
        </a>
        </div>
        <div class="bg-white rounded-3xl shadow-sm border border-gray-100 p-6 space-y-4">
        <?php if (count($recentRedemptions) > 0): ?>
            <?php foreach ($recentRedemptions as $r): ?>
            <div class="flex items-center gap-4 p-4 rounded-2xl bg-gray-50 hover:bg-light-green transition border border-transparent hover:border-primary/10">
            <div class="bg-white p-3 rounded-xl shadow-sm">
                <i data-lucide="package" class="w-6 h-6 text-primary"></i>
            </div>
            <div class="flex-1">
                <h4 class="font-bold text-gray-800 text-sm"><?= htmlspecialchars($r['rewardName']) ?></h4>
                <p class="text-xs text-gray-500"><?= date('m/d/Y', strtotime($r['createdAt'])) ?></p>
            </div>
            <div class="text-right">
                <span class="text-sm font-bold text-orange-500">-<?= $r['pointsCost'] ?></span>
            </div>
            </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="text-center py-12 text-gray-400">
            <i data-lucide="gift" class="w-12 h-12 mx-auto mb-4 opacity-10"></i>
            <p class="text-sm">Redeem your points for awesome rewards!</p>
            </div>
        <?php endif; ?>
        </div>
    </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
