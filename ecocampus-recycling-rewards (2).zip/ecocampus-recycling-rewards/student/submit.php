<?php
require_once '../config.php';
require_once '../services/db.php';

// Ensure session is started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'student') {
    header("Location: " . BASE_URL . "/login.php");
    exit;
}

$user = $_SESSION['user'];
$materials = array_filter($db->getMaterials(), fn($m) => $m['active']);
$bins = array_filter($db->getBins(), fn($b) => $b['active']);

// Prepare daily usage data
$materialUsage = [];
foreach ($materials as $m) {
    $materialUsage[$m['id']] = $db->getDailyMaterialUsage($user['id'], $m['id']);
}

$success = false;
$estimatedPoints = 0;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $materialId = $_POST['materialId'] ?? '';
    $binId = $_POST['binId'] ?? '';
    $weight = floatval($_POST['weight'] ?? 0);

    if ($materialId && $binId && $weight > 0) {
        try {
            $submission = $db->submitRecycling($user['id'], $materialId, $binId, $weight);
            $success = true;
            $estimatedPoints = $submission['pointsAwarded'];
        } catch (Exception $e) {
            $error = $e->getMessage();
        }
    }
}

require_once '../includes/header.php';
?>

<?php if ($success): ?>
<style>
    @keyframes bounce-custom {
        0%, 100% { transform: translateY(-25%); animation-timing-function: cubic-bezier(0.8, 0, 1, 1); }
        50% { transform: translateY(0); animation-timing-function: cubic-bezier(0, 0, 0.2, 1); }
    }
    .animate-bounce-3 {
        animation: bounce-custom 1s infinite;
        animation-iteration-count: 3;
    }
</style>
<div class="max-w-xl mx-auto mt-20 text-center animate-bounce-3">
    <div class="bg-white p-12 rounded-3xl shadow-2xl space-y-6">
        <div class="w-24 h-24 bg-primary text-white rounded-full flex items-center justify-center mx-auto shadow-xl">
            <i data-lucide="check-circle" class="w-12 h-12"></i>
        </div>
        <h2 class="text-3xl font-bold text-gray-800">Awesome Work!</h2>
        <p class="text-gray-500 text-lg">Your recycling log has been submitted and is awaiting administrator verification.</p>
        <p class="text-primary font-bold">Estimated Points: +<?= number_format($estimatedPoints) ?></p>
        <a href="<?= BASE_URL ?>/student/dashboard.php" class="inline-block bg-primary text-white px-6 py-3 rounded-full font-bold mt-4 hover:bg-dark-green transition">Back to Dashboard</a>
    </div>
</div>
<?php else: ?>

<div class="max-w-4xl mx-auto pb-12">
    <div class="mb-8">
    <h1 class="text-3xl font-bold text-gray-800">Log New Recycling</h1>
    <p class="text-gray-500">Every kilogram counts towards a greener campus.</p>
    </div>

    <div class="grid md:grid-cols-3 gap-8">
    <!-- Form -->
    <div class="md:col-span-2">
        <form method="POST" id="submissionForm" class="bg-white p-8 rounded-3xl shadow-sm border border-gray-100 space-y-6">
        <div class="space-y-4">
            <label class="block">
            <span class="flex items-center gap-2 text-sm font-bold text-gray-700 uppercase tracking-widest mb-2">
                <i data-lucide="package" class="w-4 h-4 text-primary"></i> Material Type
            </span>
            <select 
                name="materialId"
                id="materialSelect"
                required
                class="w-full p-4 rounded-xl border border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none transition bg-gray-50"
            >
                <option value="">Select Material</option>
                <?php foreach ($materials as $m): ?>
                <option value="<?= $m['id'] ?>" data-points="<?= $m['pointsPerKg'] ?>" data-limit="<?= $m['daily_limit'] ?>" data-usage="<?= $materialUsage[$m['id']] ?? 0 ?>"><?= htmlspecialchars($m['name']) ?> (<?= $m['pointsPerKg'] ?> pts/kg)</option>
                <?php endforeach; ?>
            </select>
            </label>

            <label class="block">
            <span class="flex items-center gap-2 text-sm font-bold text-gray-700 uppercase tracking-widest mb-2">
                <i data-lucide="map-pin" class="w-4 h-4 text-primary"></i> Bin Location
            </span>
            <select 
                name="binId"
                required
                class="w-full p-4 rounded-xl border border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none transition bg-gray-50"
            >
                <option value="">Select Bin Location</option>
                <?php foreach ($bins as $b): ?>
                <option value="<?= $b['id'] ?>"><?= htmlspecialchars($b['name']) ?> - <?= htmlspecialchars($b['location']) ?></option>
                <?php endforeach; ?>
            </select>
            </label>

            <label class="block">
            <span class="flex items-center gap-2 text-sm font-bold text-gray-700 uppercase tracking-widest mb-2">
                <i data-lucide="scale" class="w-4 h-4 text-primary"></i> Weight (kg)
            </span>
            <div class="relative">
                <input 
                type="number" step="0.1" min="0.1" required
                name="weight"
                id="weightInput"
                placeholder="Enter weight in kg"
                class="w-full p-4 rounded-xl border border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none transition bg-gray-50"
                />
                <span class="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 font-bold">KG</span>
            </div>
            </label>
        </div>

        <div class="bg-light-green p-6 rounded-2xl border border-primary/20 flex items-center justify-between">
            <div>
            <p class="text-xs font-bold text-primary uppercase tracking-widest">Estimated Reward</p>
            <p class="text-3xl font-bold text-gray-800"><span id="estimatedPoints">0</span> <span class="text-sm font-medium text-gray-500 uppercase">Points</span></p>
            </div>
            <i data-lucide="trending-up" class="w-12 h-12 text-primary opacity-20"></i>
        </div>

            <div id="limitContainer" class="hidden">
                 <div class="flex justify-between text-xs font-bold uppercase tracking-widest text-gray-500 mb-1">
                     <span>Daily Limit</span>
                     <span id="limitText">0 / 0 kg</span>
                 </div>
                 <div class="h-3 bg-gray-100 rounded-full overflow-hidden">
                     <div id="limitBar" class="h-full bg-primary transition-all duration-500" style="width: 0%"></div>
                 </div>
                 <p id="limitError" class="text-xs text-red-500 font-bold mt-1 hidden">Daily limit exceeded!</p>
            </div>

            <button 
            type="submit"
            class="w-full bg-primary text-white py-4 rounded-2xl font-bold text-lg hover:bg-dark-green transition shadow-xl"
        >
            Submit Log
        </button>
        </form>
    </div>

    <!-- Instructions -->
    <div class="space-y-6">
        <div class="bg-white p-6 rounded-3xl shadow-sm border border-gray-100">
        <h3 class="text-lg font-bold text-gray-800 flex items-center gap-2 mb-4">
            <i data-lucide="info" class="w-5 h-5 text-primary"></i> Guidelines
        </h3>
        <ul class="space-y-3 text-sm text-gray-600">
            <li class="flex gap-2">
                <div class="w-1.5 h-1.5 rounded-full bg-primary mt-1.5 flex-shrink-0"></div>
                Ensure all plastic is rinsed and clean before disposal.
            </li>
            <li class="flex gap-2">
                <div class="w-1.5 h-1.5 rounded-full bg-primary mt-1.5 flex-shrink-0"></div>
                Remove labels from metal cans if possible.
            </li>
            <li class="flex gap-2">
                <div class="w-1.5 h-1.5 rounded-full bg-primary mt-1.5 flex-shrink-0"></div>
                E-waste must be dropped specifically at certified bins.
            </li>
            <li class="flex gap-2">
                <div class="w-1.5 h-1.5 rounded-full bg-primary mt-1.5 flex-shrink-0"></div>
                Log correct weight to avoid rejection.
            </li>
        </ul>
        </div>

        <div class="bg-orange-50 p-6 rounded-3xl border border-orange-100">
        <h3 class="text-lg font-bold text-orange-700 flex items-center gap-2 mb-2">
            <i data-lucide="alert-circle" class="w-5 h-5"></i> Important
        </h3>
        <p class="text-sm text-orange-600 leading-relaxed">
            Points are only added to your account after an administrator reviews and approves the submission. This typically takes 24-48 hours.
        </p>
        </div>

        <div class="bg-primary/5 p-6 rounded-3xl border border-primary/10">
        <div class="flex items-center gap-3 mb-2">
            <i data-lucide="sparkles" class="text-primary w-5 h-5"></i>
            <p class="font-bold text-primary">Pro Tip</p>
        </div>
        <p class="text-sm text-gray-600 italic">
            "Recycling aluminum saves 95% of the energy required to make new aluminum from scratch!"
        </p>
        </div>
    </div>
    </div>
</div>

<script>
    const materialSelect = document.getElementById('materialSelect');
    const weightInput = document.getElementById('weightInput');
    const estimatedPointsEl = document.getElementById('estimatedPoints');
    
    // Limit UI Elements
    const limitContainer = document.getElementById('limitContainer');
    const limitText = document.getElementById('limitText');
    const limitBar = document.getElementById('limitBar');
    const limitError = document.getElementById('limitError');

    function updatePoints() {
        const option = materialSelect.options[materialSelect.selectedIndex];
        const points = option ? parseFloat(option.getAttribute('data-points')) : 0;
        const limit = option ? parseFloat(option.getAttribute('data-limit')) : 0;
        const usage = option ? parseFloat(option.getAttribute('data-usage')) : 0;
        
        // Show/Hide Limit UI
        if (limit > 0) {
            limitContainer.classList.remove('hidden');
        } else {
            limitContainer.classList.add('hidden');
        }

        const currentInput = parseFloat(weightInput.value) || 0;
        const total = usage + currentInput;
        
        // Update Limit Text & Bar
        if (limit > 0) {
            limitText.textContent = `${total.toFixed(1)} / ${limit} kg`;
            const percent = Math.min((total / limit) * 100, 100);
            limitBar.style.width = `${percent}%`;
            
            if (total > limit) {
                limitBar.classList.remove('bg-primary');
                limitBar.classList.add('bg-red-500');
                limitError.classList.remove('hidden');
            } else {
                limitBar.classList.add('bg-primary');
                limitBar.classList.remove('bg-red-500');
                limitError.classList.add('hidden');
            }
        }

        if (points && currentInput > 0) {
            estimatedPointsEl.textContent = (points * currentInput).toFixed(0);
        } else {
            estimatedPointsEl.textContent = '0';
        }
    }

    materialSelect.addEventListener('change', updatePoints);
    weightInput.addEventListener('input', updatePoints);
    
    // Initial call to reset state
    updatePoints();
</script>
<?php endif; ?>

<?php require_once '../includes/footer.php'; ?>
