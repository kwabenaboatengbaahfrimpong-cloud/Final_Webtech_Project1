<?php
require_once 'services/db.php';
session_start();

if (isset($_SESSION['user'])) {
    if ($_SESSION['user']['role'] === 'admin') {
        header("Location: " . BASE_URL . "/admin/dashboard.php");
    } else {
        header("Location: " . BASE_URL . "/student/dashboard.php");
    }
    exit;
}

$error = '';
$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';
    $user = $db->login($email, $password);
    
    if ($user) {
        $_SESSION['user'] = $user;
        if ($user['role'] === 'admin') {
            header("Location: " . BASE_URL . "/admin/dashboard.php");
        } else {
            header("Location: " . BASE_URL . "/student/dashboard.php");
        }
        exit;
    } else {
        $error = 'Invalid email. Please try again.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | EcoCampus</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/style.css">
    <script src="https://unpkg.com/lucide@latest"></script>
</head>
<body class="bg-cream">
    <div class="min-h-screen flex items-center justify-center p-4">
        <div class="max-w-md w-full bg-white rounded-3xl shadow-2xl overflow-hidden">
            <div class="bg-primary p-8 text-white text-center">
                <div class="inline-flex items-center justify-center w-16 h-16 bg-white/20 rounded-full mb-4">
                     <i data-lucide="leaf" class="w-10 h-10"></i>
                </div>
                <h2 class="text-3xl font-bold">Welcome Back</h2>
                <p class="text-white/80 mt-2">Continue your recycling journey</p>
            </div>
            
            <form method="POST" class="p-8 space-y-6">
                <?php if ($error): ?>
                <div class="flex items-center gap-2 p-4 bg-red-50 text-red-600 rounded-xl text-sm border border-red-100">
                    <i data-lucide="alert-circle" class="w-5 h-5 flex-shrink-0"></i>
                    <p><?= htmlspecialchars($error) ?></p>
                </div>
                <?php endif; ?>

                <div class="space-y-2">
                    <label class="text-sm font-semibold text-gray-700 ml-1">University Email</label>
                    <div class="relative">
                        <i data-lucide="mail" class="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400"></i>
                        <input 
                            type="email" 
                            name="email"
                            required
                            value="<?= htmlspecialchars($email) ?>"
                            placeholder="student@university.edu"
                            class="w-full pl-12 pr-4 py-3 rounded-xl border border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none transition"
                        />
                    </div>
                </div>

                <div class="space-y-2">
                    <label class="text-sm font-semibold text-gray-700 ml-1">Password</label>
                    <div class="relative">
                        <i data-lucide="lock" class="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400"></i>
                        <input 
                            type="password" 
                            name="password"
                            id="password"
                            required
                            placeholder="••••••••"
                            class="w-full pl-12 pr-10 py-3 rounded-xl border border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none transition"
                        />
                        <button type="button" onclick="togglePassword()" class="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-primary">
                            <i data-lucide="eye" class="w-4 h-4"></i>
                        </button>
                    </div>
                </div>

                <button 
                    type="submit"
                    class="w-full bg-primary text-white py-4 rounded-xl font-bold text-lg hover:bg-dark-green transition shadow-lg flex items-center justify-center gap-2"
                >
                    Sign In
                </button>

                <div class="text-center">
                    <p class="text-gray-500">Don't have an account? <a href="<?= BASE_URL ?>/register.php" class="text-primary font-bold hover:underline">Register now</a></p>
                </div>


            </form>
        </div>
    </div>
    <script>
        lucide.createIcons();
        function togglePassword() {
            const input = document.getElementById('password');
            if (input.type === 'password') {
                input.type = 'text';
            } else {
                input.type = 'password';
            }
        }
    </script>
</body>
</html>
