<?php
require_once 'config.php';
session_start();
if (isset($_SESSION['user'])) {
    if ($_SESSION['user']['role'] === 'admin') {
        header("Location: " . BASE_URL . "/admin/dashboard.php");
    } else {
        header("Location: " . BASE_URL . "/student/dashboard.php");
    }
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EcoCampus | Recycle & Earn</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/style.css">
    <script src="https://unpkg.com/lucide@latest"></script>
</head>
<body class="bg-cream font-sans">
    <div class="min-h-screen">
      <!-- Header -->
      <header class="container mx-auto px-6 py-6 flex justify-between items-center">
        <div class="flex items-center gap-2 text-primary font-bold text-2xl">
          <i data-lucide="leaf" class="w-10 h-10"></i>
          <span>EcoCampus</span>
        </div>
        <div class="flex gap-4">
          <a href="<?= BASE_URL ?>/login.php" class="text-primary font-semibold hover:text-dark-green transition pt-2">Login</a>
          <a href="<?= BASE_URL ?>/register.php" class="bg-primary text-white px-6 py-2 rounded-full font-semibold hover:bg-dark-green transition shadow-lg">Sign Up</a>
        </div>
      </header>

      <!-- Hero Section -->
      <section class="container mx-auto px-6 py-20 flex flex-col md:flex-row items-center">
        <div class="md:w-1/2 space-y-8">
          <h1 class="text-5xl md:text-7xl font-bold text-gray-800 leading-tight">
            Turn Your <span class="text-primary underline">Recycling</span> Into Rewards.
          </h1>
          <p class="text-xl text-gray-600 max-w-lg">
            Join thousands of university students making the campus greener. Log your recycling activities, earn points, and redeem amazing rewards.
          </p>
          <div class="flex gap-4">
            <a href="<?= BASE_URL ?>/register.php" class="bg-primary text-white px-8 py-4 rounded-full font-bold text-lg hover:bg-dark-green transition shadow-xl flex items-center gap-2 group">
              Get Started <i data-lucide="arrow-right" class="group-hover:translate-x-1 transition"></i>
            </a>
          </div>
        </div>
        <div class="md:w-1/2 mt-12 md:mt-0 relative">
          <img src="https://www.ashesi.org/wp-content/uploads/2025/01/AI-0087-scaled.jpg" alt="Recycling" class="rounded-3xl shadow-2xl border-8 border-white" />
          <div class="absolute -bottom-10 -left-10 bg-white p-6 rounded-2xl shadow-xl flex items-center gap-4 border border-primary/10">
            <div class="bg-primary/10 p-4 rounded-xl">
              <i data-lucide="trophy" class="text-primary w-8 h-8"></i>
            </div>
            <div>
              <p class="font-bold text-2xl text-gray-800">5,432</p>
              <p class="text-gray-500 font-medium text-sm uppercase tracking-wider">Students Recycling</p>
            </div>
          </div>
        </div>
      </section>

      <!-- Features - How It Works -->
      <section class="bg-white py-24 mt-20 relative overflow-hidden">
        <div class="absolute top-0 right-0 w-64 h-64 bg-primary/5 rounded-full -mr-32 -mt-32 blur-3xl"></div>
        <div class="container mx-auto px-6 relative">
          <div class="text-center mb-16">
            <p className="text-primary font-bold uppercase tracking-widest text-sm mb-2">The Journey</p>
            <h2 class="text-4xl font-bold text-gray-800 mb-4">How It Works</h2>
            <div class="w-16 h-1.5 bg-primary mx-auto rounded-full"></div>
          </div>
          <div class="grid md:grid-cols-3 gap-12">
              <div class="p-10 rounded-[2.5rem] bg-light-green/30 border border-primary/5 hover:border-primary/20 hover:shadow-2xl hover:shadow-primary/5 transition-all duration-500 group">
                <div class="bg-white w-20 h-20 rounded-[1.5rem] flex items-center justify-center mb-8 shadow-sm text-primary group-hover:bg-primary group-hover:text-white transition-all">
                  <i data-lucide="recycle" class="w-10 h-10"></i>
                </div>
                <h3 class="text-2xl font-bold mb-4 text-gray-800">Collect & Drop</h3>
                <p class="text-gray-600 leading-relaxed font-medium opacity-80">Gather plastic, metal, or paper and drop them at any of our designated smart bins around the campus.</p>
              </div>

              <div class="p-10 rounded-[2.5rem] bg-light-green/30 border border-primary/5 hover:border-primary/20 hover:shadow-2xl hover:shadow-primary/5 transition-all duration-500 group">
                <div class="bg-white w-20 h-20 rounded-[1.5rem] flex items-center justify-center mb-8 shadow-sm text-primary group-hover:bg-primary group-hover:text-white transition-all">
                  <i data-lucide="shield-check" class="w-10 h-10"></i>
                </div>
                <h3 class="text-2xl font-bold mb-4 text-gray-800">Log & Verify</h3>
                <p class="text-gray-600 leading-relaxed font-medium opacity-80">Quickly log your drop-off in the app. Our administrators verify your submission within 24 hours.</p>
              </div>

              <div class="p-10 rounded-[2.5rem] bg-light-green/30 border border-primary/5 hover:border-primary/20 hover:shadow-2xl hover:shadow-primary/5 transition-all duration-500 group">
                <div class="bg-white w-20 h-20 rounded-[1.5rem] flex items-center justify-center mb-8 shadow-sm text-primary group-hover:bg-primary group-hover:text-white transition-all">
                  <i data-lucide="gift" class="w-10 h-10"></i>
                </div>
                <h3 class="text-2xl font-bold mb-4 text-gray-800">Earn & Redeem</h3>
                <p class="text-gray-600 leading-relaxed font-medium opacity-80">Watch your points grow and redeem them for exclusive campus vouchers, gear, and sustainable products.</p>
              </div>
          </div>
        </div>
      </section>

      <!-- Stats -->
      <section class="bg-primary py-24">
        <div class="container mx-auto px-6 grid grid-cols-2 md:grid-cols-4 gap-12 text-center">
          <div>
            <p class="text-5xl font-bold text-white mb-2">15.2k</p>
            <p class="text-white/60 uppercase tracking-widest text-xs font-bold">Kg Recycled</p>
          </div>
          <div>
            <p class="text-5xl font-bold text-white mb-2">320k</p>
            <p class="text-white/60 uppercase tracking-widest text-xs font-bold">Points Earned</p>
          </div>
          <div>
            <p class="text-5xl font-bold text-white mb-2">1.2k</p>
            <p class="text-white/60 uppercase tracking-widest text-xs font-bold">Trees Saved</p>
          </div>
          <div>
            <p class="text-5xl font-bold text-white mb-2">450+</p>
            <p class="text-white/60 uppercase tracking-widest text-xs font-bold">Rewards Claimed</p>
          </div>
        </div>
      </section>

      <!-- Footer -->
      <footer class="bg-gray-800 text-white py-16">
        <div class="container mx-auto px-6 text-center">
          <div class="flex items-center justify-center gap-2 mb-8">
            <i data-lucide="leaf" class="w-10 h-10 text-primary"></i>
            <span class="text-3xl font-bold">EcoCampus</span>
          </div>
          <p class="text-gray-400 max-w-lg mx-auto mb-10 text-lg">
            Empowering the next generation of university students to lead the way in campus sustainability and environmental action.
          </p>
          <div class="flex justify-center gap-8 mb-12 text-gray-400 font-bold uppercase tracking-widest text-xs">
            <a href="#" class="hover:text-primary transition">About Us</a>
            <a href="#" class="hover:text-primary transition">Contact</a>
            <a href="#" class="hover:text-primary transition">Terms</a>
          </div>
          <p class="text-gray-500 text-sm">© 2024 EcoCampus Platform. All rights reserved.</p>
        </div>
      </footer>
    </div>
    <script>
        lucide.createIcons();
    </script>
    <script>
        lucide.createIcons();
    </script>
</body>
</html>
