<?php
// Database Configuration
// Use environment variables if set, otherwise fall back to local defaults
define('DB_HOST', getenv('DB_HOST') ?: 'localhost');
define('DB_NAME', getenv('DB_NAME') ?: 'webtech_2025A_kwame_boateng');
define('DB_USER', getenv('DB_USER') ?: 'kwame.boateng');
define('DB_PASS', getenv('DB_PASS') ?: 'Zoom@0011');


// Dynamic Base URL Detection
// 1. Check if BASE_URL is manually defined in environment
$envBaseUrl = getenv('BASE_URL');

if ($envBaseUrl !== false) {
    define('BASE_URL', rtrim($envBaseUrl, '/'));
} else {
    // 2. Smart Auto-detect based on script location vs config location
    // This works even if DOCUMENT_ROOT is different (e.g. ~username urls)
    
    $scriptPath = str_replace('\\', '/', dirname($_SERVER['SCRIPT_FILENAME']));
    $configPath = str_replace('\\', '/', __DIR__);
    $scriptUrl = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME']));
    
    // Calculate relative path from script execution directory to config directory
    // Example: Script is /admin/dash.php, Config is /config.php. 
    // We need to go ".." to get from script to config.
    
    // Simple verification: if config is inside script's path (unlikely, usually other way around or parallel)
    // Most common: config is root, script is root or subdir.
    
    if ($scriptPath === $configPath) {
        // Config and Script are in same directory
        define('BASE_URL', $scriptUrl === '/' ? '' : $scriptUrl);
    } else {
        // Script is likely in a subdirectory
        // Find how many levels deep we are relative to config
        // Note: This naive string subtraction works if we are just traversing down.
        // If we are symlinked elsewhere, we might need a manual override.
        
        if (strpos($scriptPath, $configPath) === 0) {
            // Script is inside the project tree
            $subdir = substr($scriptPath, strlen($configPath));
            // $subdir is like "/admin". We need to strip this from the end of $scriptUrl
            // e.g. scriptUrl = /~user/project/admin
            
            // Remove the subdir from the end of the script URL
            if (substr($scriptUrl, -strlen($subdir)) === $subdir) {
                $baseUrl = substr($scriptUrl, 0, -strlen($subdir));
                define('BASE_URL', $baseUrl === '/' ? '' : $baseUrl);
            } else {
                // Fallback: This usually shouldn't happen unless URL rewriting is involved
                 define('BASE_URL', $scriptUrl);
            }
        } else {
             // Fallback: Just use current dir or manual override
             // This happens if included from outside? Rare.
             define('BASE_URL', ''); 
        }
    }
}

// MANUAL OVERRIDE (Uncomment if still failing)
// define('BASE_URL', '/~kofi.agyeman/ecocampus-recycling-rewards'); 

// Set up PDO connection
function getDBConnection() {
    try {
        $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4";
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ];
        return new PDO($dsn, DB_USER, DB_PASS, $options);
    } catch (\PDOException $e) {
        die("Database Connection Failed: " . $e->getMessage());
    }
}
?>
