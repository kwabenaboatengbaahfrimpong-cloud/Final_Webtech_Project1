<?php
require_once 'config.php';
require_once 'services/db.php';

try {
    $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4";
    $pdo = new PDO($dsn, DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);

    $count = $pdo->exec("UPDATE materials SET daily_limit = 15 WHERE daily_limit < 15");
    echo "Successfully updated $count materials to the new minimum daily limit of 15kg.";

} catch (PDOException $e) {
    echo "Error updating limits: " . $e->getMessage();
}
?>
