<?php
require_once 'services/db.php';
$pdo = getDBConnection();
$stmt = $pdo->query("SHOW CREATE TABLE rewards");
print_r($stmt->fetch(PDO::FETCH_ASSOC));
?>
