<?php
require_once '../includes/header.php';
require_once '../services/db.php';

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: " . BASE_URL . "/login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'] ?? '';
    if ($id) {
        $db->fulfillRedemption($id);
    }
}

$redemptions = $db->getRedemptions();
// Default sort by Pending first
usort($redemptions, function($a, $b) {
    if ($a['status'] === $b['status']) return 0;
    return $a['status'] === 'pending' ? -1 : 1;
});

?>

<div class="max-w-7xl mx-auto space-y-8 pb-12">
    <div class="flex flex-col md:flex-row md:items-center justify-between gap-6">
    <div>
        <h1 class="text-3xl font-bold text-gray-800">Redemption Requests</h1>
        <p class="text-gray-500">Fulfill reward requests and manage inventory delivery.</p>
    </div>
    </div>

    <div class="space-y-6">
    <?php foreach ($redemptions as $r): ?>
        <div class="bg-white rounded-[2rem] shadow-sm border border-gray-100 overflow-hidden flex flex-col md:flex-row">
        <div class="p-8 flex-1 flex items-center gap-6">
            <div class="w-16 h-16 rounded-2xl flex items-center justify-center font-bold text-2xl shadow-sm text-white <?= $r['status'] === 'pending' ? 'bg-purple-500' : 'bg-gray-300' ?>">
            <i data-lucide="<?= $r['status'] === 'pending' ? 'gift' : 'check' ?>" class="w-8 h-8"></i>
            </div>
            <div>
            <div class="flex items-center gap-3 mb-1">
                <h3 class="text-xl font-bold text-gray-800"><?= htmlspecialchars($r['rewardName']) ?></h3>
                <span class="text-[10px] px-2 py-0.5 rounded-full font-bold uppercase tracking-wider 
                <?= $r['status'] === 'pending' ? 'bg-purple-100 text-purple-600' : ($r['status'] === 'fulfilled' ? 'bg-green-100 text-green-600' : 'bg-gray-100 text-gray-600') ?>">
                <?= $r['status'] ?>
                </span>
            </div>
            <div class="flex flex-col md:flex-row md:items-center gap-x-6 gap-y-2 text-sm text-gray-500 font-medium">
                <span class="flex items-center gap-1.5"><i data-lucide="user" class="w-4 h-4 text-gray-400"></i> Student: <span class="text-gray-700"><?= isset($r['userName']) ? htmlspecialchars($r['userName']) : 'Unknown' ?></span></span>
                <span class="flex items-center gap-1.5"><i data-lucide="clock" class="w-4 h-4 text-gray-400"></i> Requested: <?= date('M j, Y h:i A', strtotime($r['createdAt'])) ?></span>
                <span class="text-primary font-bold">-<?= $r['pointsCost'] ?> pts</span>
            </div>
            </div>
        </div>
        
        <?php if ($r['status'] === 'pending'): ?>
        <div class="bg-gray-50 p-8 flex items-center border-l md:border-l border-gray-100 md:w-48 justify-center">
            <form method="POST">
            <input type="hidden" name="id" value="<?= $r['id'] ?>">
            <button 
                type="submit" 
                onclick="return confirm('Mark this reward as fulfilled?')"
                class="bg-purple-600 text-white px-6 py-3 rounded-xl font-bold hover:bg-purple-700 transition shadow-lg flex items-center gap-2"
            >
                <i data-lucide="check" class="w-5 h-5"></i> Fulfill
            </button>
            </form>
        </div>
        <?php else: ?>
        <div class="bg-gray-50 p-8 flex flex-col justify-center items-end border-l border-gray-100 md:w-48 text-right">
            <p class="text-xs font-bold text-gray-400 uppercase tracking-widest mb-1">Processed</p>
            <p class="text-sm font-bold text-green-600 flex items-center gap-1">
            <i data-lucide="check-circle" class="w-4 h-4"></i> Done
            </p>
        </div>
        <?php endif; ?>
        </div>
    <?php endforeach; ?>

    <?php if (empty($redemptions)): ?>
        <div class="py-20 text-center space-y-4">
        <i data-lucide="inbox" class="w-16 h-16 mx-auto text-gray-200"></i>
        <p class="text-gray-500">No redemption requests found.</p>
        </div>
    <?php endif; ?>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
