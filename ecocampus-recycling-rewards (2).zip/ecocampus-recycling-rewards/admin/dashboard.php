<?php
require_once '../includes/header.php';
require_once '../services/db.php';

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: " . BASE_URL . "/login.php");
    exit;
}

$users = $db->getUsers();
$students = array_filter($users, fn($u) => $u['role'] === 'student');
$submissions = $db->getSubmissions();
$redemptions = $db->getRedemptions();
$materials = $db->getMaterials();
$bins = $db->getBins();

$stats = [
    'totalStudents' => count($students),
    'pendingSubmissions' => count(array_filter($submissions, fn($s) => $s['status'] === 'pending')),
    'pendingRedemptions' => count(array_filter($redemptions, fn($r) => $r['status'] === 'pending')),
    'pointsAwarded' => array_reduce(array_filter($submissions, fn($s) => $s['status'] === 'approved'), fn($acc, $s) => $acc + $s['pointsAwarded'], 0),
    'materialsCount' => count($materials),
    'binsCount' => count($bins)
];

$recentSubs = array_slice(array_filter($submissions, fn($s) => $s['status'] === 'pending'), 0, 5);
?>

<div class="max-w-7xl mx-auto space-y-8 pb-12">
    <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
    <div>
        <h1 class="text-3xl font-bold text-gray-800">Admin Command Center</h1>
        <p class="text-gray-500">Managing EcoCampus Sustainability</p>
    </div>
    <div class="flex gap-3">
        <div class="bg-white px-4 py-2 rounded-xl shadow-sm border border-gray-100 flex items-center gap-2">
        <span class="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
        <span class="text-sm font-bold text-gray-600 uppercase tracking-widest">System Online</span>
        </div>
    </div>
    </div>

    <!-- Primary Stats -->
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
    <div class="bg-white p-6 rounded-3xl shadow-sm border border-gray-100 relative group overflow-hidden">
        <div class="absolute top-0 right-0 w-20 h-20 bg-blue-50 rounded-bl-full -mr-10 -mt-10 group-hover:scale-110 transition-transform"></div>
        <i data-lucide="users" class="text-blue-500 mb-4 w-8 h-8"></i>
        <p class="text-3xl font-bold text-gray-800"><?= $stats['totalStudents'] ?></p>
        <p class="text-xs font-bold text-gray-400 uppercase tracking-[0.2em] mt-1">Total Students</p>
    </div>

    <div class="bg-white p-6 rounded-3xl shadow-sm border border-gray-100 relative group overflow-hidden">
        <div class="absolute top-0 right-0 w-20 h-20 bg-orange-50 rounded-bl-full -mr-10 -mt-10 group-hover:scale-110 transition-transform"></div>
        <i data-lucide="clock" class="text-orange-500 mb-4 w-8 h-8"></i>
        <p class="text-3xl font-bold text-gray-800"><?= $stats['pendingSubmissions'] ?></p>
        <p class="text-xs font-bold text-gray-400 uppercase tracking-[0.2em] mt-1 text-orange-600">Pending Reviews</p>
    </div>

    <div class="bg-white p-6 rounded-3xl shadow-sm border border-gray-100 relative group overflow-hidden">
        <div class="absolute top-0 right-0 w-20 h-20 bg-primary/5 rounded-bl-full -mr-10 -mt-10 group-hover:scale-110 transition-transform"></div>
        <i data-lucide="sparkles" class="text-primary mb-4 w-8 h-8"></i>
        <p class="text-3xl font-bold text-gray-800"><?= number_format($stats['pointsAwarded']) ?></p>
        <p class="text-xs font-bold text-gray-400 uppercase tracking-[0.2em] mt-1">Points Awarded</p>
    </div>

    <div class="bg-white p-6 rounded-3xl shadow-sm border border-gray-100 relative group overflow-hidden">
        <div class="absolute top-0 right-0 w-20 h-20 bg-purple-50 rounded-bl-full -mr-10 -mt-10 group-hover:scale-110 transition-transform"></div>
        <i data-lucide="gift" class="text-purple-500 mb-4 w-8 h-8"></i>
        <p class="text-3xl font-bold text-gray-800"><?= $stats['pendingRedemptions'] ?></p>
        <p class="text-xs font-bold text-gray-400 uppercase tracking-[0.2em] mt-1 text-purple-600">Redemptions</p>
    </div>
    </div>

    <div class="grid lg:grid-cols-3 gap-8">
    <!-- Quick Review Panel -->
    <div class="lg:col-span-2 space-y-4">
        <div class="flex justify-between items-center px-2">
        <h2 class="text-xl font-bold text-gray-800 flex items-center gap-2">
            <i data-lucide="recycle" class="w-5 h-5 text-orange-500"></i> Pending Approval
        </h2>
        <a href="<?= BASE_URL ?>/admin/submissions.php" class="text-primary font-bold text-sm hover:underline flex items-center gap-1">
            View All <i data-lucide="chevron-right" class="w-4 h-4"></i>
        </a>
        </div>
        
        <div class="bg-white rounded-3xl shadow-sm border border-gray-100 overflow-hidden">
        <?php if (count($recentSubs) > 0): ?>
            <div class="divide-y divide-gray-50">
            <?php foreach ($recentSubs as $s): ?>
                <div class="p-6 flex items-center justify-between hover:bg-gray-50 transition">
                <div class="flex items-center gap-4">
                    <div class="bg-primary/10 p-3 rounded-2xl text-primary font-bold">
                    <?= strtoupper(substr($s['userName'], 0, 1)) ?>
                    </div>
                    <div>
                    <p class="font-bold text-gray-800"><?= htmlspecialchars($s['userName']) ?></p>
                    <p class="text-xs text-gray-500"><?= htmlspecialchars($s['materialName']) ?> • <?= $s['weightKg'] ?>kg • <?= htmlspecialchars($s['binName']) ?></p>
                    </div>
                </div>
                <a href="<?= BASE_URL ?>/admin/submissions.php" class="bg-primary/10 text-primary px-4 py-2 rounded-xl text-xs font-bold hover:bg-primary hover:text-white transition">
                    REVIEW
                </a>
                </div>
            <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="p-12 text-center text-gray-500">
            <i data-lucide="check-circle" class="w-12 h-12 mx-auto mb-4 opacity-10 text-primary"></i>
            <p>All caught up! No pending submissions.</p>
            </div>
        <?php endif; ?>
        </div>
    </div>

    <!-- Management Quick Links -->
    <div class="space-y-4">
        <h2 class="text-xl font-bold text-gray-800 px-2">Management</h2>
        <div class="grid gap-4">
        <a href="<?= BASE_URL ?>/admin/materials.php" class="flex items-center gap-4 p-5 rounded-3xl bg-white border border-gray-100 hover:shadow-lg hover:-translate-y-1 transition group">
            <div class="bg-blue-50 p-4 rounded-2xl group-hover:bg-blue-500 group-hover:text-white transition">
            <i data-lucide="trash-2" class="w-6 h-6"></i>
            </div>
            <div>
            <p class="font-bold text-gray-800">Materials</p>
            <p class="text-xs text-gray-500"><?= $stats['materialsCount'] ?> Active Types</p>
            </div>
        </a>

        <a href="<?= BASE_URL ?>/admin/bins.php" class="flex items-center gap-4 p-5 rounded-3xl bg-white border border-gray-100 hover:shadow-lg hover:-translate-y-1 transition group">
            <div class="bg-green-50 p-4 rounded-2xl group-hover:bg-green-500 group-hover:text-white transition">
            <i data-lucide="map-pin" class="w-6 h-6"></i>
            </div>
            <div>
            <p class="font-bold text-gray-800">Recycling Bins</p>
            <p class="text-xs text-gray-500"><?= $stats['binsCount'] ?> Locations</p>
            </div>
        </a>

        <a href="<?= BASE_URL ?>/admin/manage-rewards.php" class="flex items-center gap-4 p-5 rounded-3xl bg-white border border-gray-100 hover:shadow-lg hover:-translate-y-1 transition group">
            <div class="bg-purple-50 p-4 rounded-2xl group-hover:bg-purple-500 group-hover:text-white transition">
            <i data-lucide="package" class="w-6 h-6"></i>
            </div>
            <div>
            <p class="font-bold text-gray-800">Rewards Catalog</p>
            <p class="text-xs text-gray-500">Manage Stock & Pricing</p>
            </div>
        </a>
        </div>

        <div class="bg-primary/5 p-6 rounded-3xl border border-primary/10 mt-6">
        <h3 class="text-sm font-bold text-primary uppercase tracking-widest mb-3">Admin Notice</h3>
        <p class="text-sm text-gray-600 leading-relaxed italic">
            "Remember to verify student weights against bin logs daily for maximum integrity of the reward system."
        </p>
        </div>
    </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
