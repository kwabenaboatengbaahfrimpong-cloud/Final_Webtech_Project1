<?php
require_once '../includes/header.php';
require_once '../services/db.php';

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: " . BASE_URL . "/login.php");
    exit;
}

// Handle Actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'] ?? '';
    $action = $_POST['action'] ?? '';
    $notes = $_POST['notes'] ?? '';

    if ($id && $action) {
        if ($action === 'approve') {
            $db->approveSubmission($id, $notes ?: 'Verified and approved.');
        } elseif ($action === 'reject') {
            $db->rejectSubmission($id, $notes ?: 'Submission invalid or incorrect material.');
        }
    }
}

$submissions = $db->getSubmissions();
$filter = $_GET['filter'] ?? 'all';
$search = $_GET['search'] ?? '';

$filtered = array_filter($submissions, function($s) use ($filter, $search) {
    $matchesFilter = $filter === 'all' || $s['status'] === $filter;
    $matchesSearch = empty($search) || stripos($s['userName'], $search) !== false || stripos($s['materialName'], $search) !== false;
    return $matchesFilter && $matchesSearch;
});

?>

<div class="max-w-7xl mx-auto space-y-8 pb-12">
    <div class="flex flex-col md:flex-row md:items-center justify-between gap-6">
    <div>
        <h1 class="text-3xl font-bold text-gray-800">Submission Review</h1>
        <p class="text-gray-500">Verify and award points for student recycling efforts.</p>
    </div>
    <div class="flex gap-2">
        <?php foreach (['all', 'pending', 'approved', 'rejected'] as $f): ?>
        <a 
            href="?filter=<?= $f ?>"
            class="px-4 py-2 rounded-xl text-xs font-bold uppercase tracking-widest transition-all 
            <?= $filter === $f ? 'bg-primary text-white shadow-lg' : 'bg-white text-gray-500 hover:bg-gray-50 border border-gray-100' ?>"
        >
            <?= $f ?>
        </a>
        <?php endforeach; ?>
    </div>
    </div>

    <form class="relative max-w-md">
        <input type="hidden" name="filter" value="<?= htmlspecialchars($filter) ?>">
        <i data-lucide="search" class="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5"></i>
        <input 
            type="text"
            name="search"
            value="<?= htmlspecialchars($search) ?>"
            placeholder="Search students or materials..."
            onchange="this.form.submit()"
            class="w-full pl-12 pr-4 py-3 rounded-2xl border border-gray-200 outline-none focus:ring-2 focus:ring-primary/20 bg-white transition shadow-sm"
        />
    </form>

    <div class="grid gap-6">
    <?php foreach ($filtered as $s): ?>
        <div class="bg-white rounded-[2rem] shadow-sm border border-gray-100 overflow-hidden transition-all duration-300">
        <div class="p-6 md:p-8 flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div class="flex items-center gap-6">
            <div class="w-16 h-16 rounded-[1.5rem] flex items-center justify-center font-bold text-2xl shadow-sm 
                <?= $s['status'] === 'pending' ? 'bg-orange-50 text-orange-500' : ($s['status'] === 'approved' ? 'bg-green-50 text-green-500' : 'bg-red-50 text-red-500') ?>">
                <?= strtoupper(substr($s['userName'], 0, 1)) ?>
            </div>
            <div>
                <div class="flex items-center gap-2 mb-1">
                <h3 class="text-xl font-bold text-gray-800"><?= htmlspecialchars($s['userName']) ?></h3>
                <span class="text-[10px] px-2 py-0.5 rounded-full font-bold uppercase tracking-wider 
                    <?= $s['status'] === 'pending' ? 'bg-orange-100 text-orange-600' : ($s['status'] === 'approved' ? 'bg-green-100 text-green-600' : 'bg-red-100 text-red-600') ?>">
                    <?= $s['status'] ?>
                </span>
                </div>
                <div class="flex flex-wrap gap-y-1 gap-x-4 text-sm text-gray-500 font-medium">
                <span class="flex items-center gap-1.5"><i data-lucide="recycle" class="w-4 h-4 text-primary"></i> <?= htmlspecialchars($s['materialName']) ?> (<?= $s['weightKg'] ?>kg)</span>
                <span class="flex items-center gap-1.5"><i data-lucide="clock" class="w-4 h-4"></i> <?= date('m/d/Y H:i', strtotime($s['createdAt'])) ?></span>
                <span class="text-primary font-bold">+<?= $s['pointsAwarded'] ?> pts potential</span>
                </div>
            </div>
            </div>

            <?php if ($s['status'] === 'pending'): ?>
            <div class="flex gap-3">
                <button 
                onclick="toggleAction('<?= $s['id'] ?>')"
                class="flex-1 md:flex-none px-6 py-3 rounded-2xl font-bold text-gray-600 hover:bg-gray-50 border border-gray-200 transition"
                >
                Action
                </button>
            </div>
            <?php else: ?>
            <div class="text-right">
                <p class="text-xs font-bold text-gray-400 uppercase tracking-widest mb-1">Review Date</p>
                <p class="text-sm font-medium text-gray-700"><?= isset($s['reviewedAt']) ? date('m/d/Y', strtotime($s['reviewedAt'])) : 'N/A' ?></p>
            </div>
            <?php endif; ?>
        </div>

        <!-- Action Panel -->
        <div id="action-<?= $s['id'] ?>" class="hidden p-8 bg-gray-50 border-t border-gray-100 animate-in slide-in-from-top-4 duration-300">
            <form method="POST" class="max-w-2xl">
            <input type="hidden" name="id" value="<?= $s['id'] ?>">
            <h4 class="font-bold text-gray-700 mb-3 flex items-center gap-2">
                <i data-lucide="message-square" class="w-4 h-4"></i> Administrator Notes
            </h4>
            <textarea 
                name="notes"
                placeholder="Add feedback for the student..."
                class="w-full p-4 rounded-xl border border-gray-200 outline-none focus:ring-2 focus:ring-primary/20 bg-white min-h-[100px] mb-6"
            ></textarea>
            <div class="flex gap-4">
                <button 
                type="submit"
                name="action"
                value="approve"
                class="flex-1 bg-primary text-white py-4 rounded-2xl font-bold hover:bg-dark-green transition shadow-lg flex items-center justify-center gap-2"
                >
                <i data-lucide="check-circle" class="w-5 h-5"></i> Approve & Award
                </button>
                <button 
                type="submit"
                name="action"
                value="reject"
                class="flex-1 bg-red-500 text-white py-4 rounded-2xl font-bold hover:bg-red-600 transition shadow-lg flex items-center justify-center gap-2"
                >
                <i data-lucide="x-circle" class="w-5 h-5"></i> Reject
                </button>
            </div>
            </form>
        </div>

        <?php if (isset($s['adminNotes']) && $s['status'] !== 'pending'): ?>
            <div class="px-8 pb-8">
            <div class="p-4 bg-gray-50 rounded-2xl border border-gray-100">
                <p class="text-xs font-bold text-gray-400 uppercase tracking-widest mb-1">Admin Notes</p>
                <p class="text-sm text-gray-600 italic">"<?= htmlspecialchars($s['adminNotes']) ?>"</p>
            </div>
            </div>
        <?php endif; ?>
        </div>
    <?php endforeach; ?>

    <?php if (empty($filtered)): ?>
        <div class="py-20 text-center space-y-4">
        <i data-lucide="recycle" class="w-16 h-16 mx-auto text-gray-200"></i>
        <h3 class="text-xl font-bold text-gray-800">No Submissions Found</h3>
        <p class="text-gray-500">Try adjusting your filters or search.</p>
        </div>
    <?php endif; ?>
    </div>
</div>

<script>
    function toggleAction(id) {
        document.getElementById('action-' + id).classList.toggle('hidden');
    }
</script>

<?php require_once '../includes/footer.php'; ?>
