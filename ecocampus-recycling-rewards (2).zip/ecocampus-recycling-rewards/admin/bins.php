<?php
require_once '../includes/header.php';
require_once '../services/db.php';

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: " . BASE_URL . "/login.php");
    exit;
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'add') {
        $name = $_POST['name'] ?? '';
        $location = $_POST['location'] ?? '';
        $lat = floatval($_POST['lat'] ?? 0);
        $lng = floatval($_POST['lng'] ?? 0);
        $type = $_POST['type'] ?? 'general';
        
        if ($name && $location) {
            $db->addBin($name, $location, $lat, $lng, $type);
            $success = "Bin added successfully.";
        } else {
            $error = "Name and location are required.";
        }
    } elseif ($action === 'toggle') {
        $id = $_POST['id'] ?? '';
        if ($id) {
            $db->toggleBin($id);
            $success = "Bin status updated.";
        }
    }
}

$bins = $db->getBins();
?>

<div class="max-w-7xl mx-auto space-y-8 pb-12">
    <div class="flex flex-col md:flex-row md:items-center justify-between gap-6">
    <div>
        <h1 class="text-3xl font-bold text-gray-800">Recycling Bins</h1>
        <p class="text-gray-500">Manage campus bin locations and status.</p>
    </div>
    <button onclick="document.getElementById('addBinModal').classList.remove('hidden')" class="bg-primary text-white px-6 py-3 rounded-2xl font-bold hover:bg-dark-green transition shadow-lg flex items-center gap-2">
        <i data-lucide="plus" class="w-5 h-5"></i> Add Bin
    </button>
    </div>

    <?php if ($error): ?>
    <div class="bg-red-50 text-red-700 p-4 rounded-xl border border-red-100 flex items-center gap-2">
        <i data-lucide="alert-triangle" class="w-5 h-5"></i> <?= htmlspecialchars($error) ?>
    </div>
    <?php endif; ?>

    <?php if ($success): ?>
    <div class="bg-green-50 text-green-700 p-4 rounded-xl border border-green-100 flex items-center gap-2">
        <i data-lucide="check-circle" class="w-5 h-5"></i> <?= htmlspecialchars($success) ?>
    </div>
    <?php endif; ?>

    <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
    <?php foreach ($bins as $b): ?>
        <div class="bg-white rounded-[2rem] shadow-sm border border-gray-100 overflow-hidden group">
        <div class="p-8">
            <div class="flex justify-between items-start mb-6">
            <div class="bg-green-50 p-4 rounded-2xl text-green-600">
                <i data-lucide="map-pin" class="w-8 h-8"></i>
            </div>
            <form method="POST">
                <input type="hidden" name="action" value="toggle">
                <input type="hidden" name="id" value="<?= $b['id'] ?>">
                <button 
                type="submit"
                class="w-12 h-7 rounded-full transition-colors relative <?= $b['active'] ? 'bg-primary' : 'bg-gray-200' ?>"
                title="Toggle Active Status"
                >
                <span class="absolute top-1 left-1 bg-white w-5 h-5 rounded-full shadow-sm transition-transform <?= $b['active'] ? 'translate-x-5' : '' ?>"></span>
                </button>
            </form>
            </div>
            
            <h3 class="text-xl font-bold text-gray-800 mb-2"><?= htmlspecialchars($b['name']) ?></h3>
            <p class="text-gray-500 mb-4 flex items-center gap-2">
            <i data-lucide="navigation" class="w-4 h-4"></i> <?= htmlspecialchars($b['location']) ?>
            </p>
            
            <div class="space-y-3">
            <div class="flex items-center justify-between text-sm">
                <span class="text-gray-500">Type</span>
                <span class="font-bold text-gray-700 capitalize"><?= htmlspecialchars($b['type']) ?></span>
            </div>
            <div class="flex items-center justify-between text-sm">
                <span class="text-gray-500">Coordinates</span>
                <span class="font-mono text-xs bg-gray-50 px-2 py-1 rounded"><?= $b['lat'] ?>, <?= $b['lng'] ?></span>
            </div>
            <div class="flex items-center justify-between text-sm">
                <span class="text-gray-500">Status</span>
                <span class="font-bold <?= $b['active'] ? 'text-green-600' : 'text-gray-400' ?>">
                <?= $b['active'] ? 'Operational' : 'Maintenance' ?>
                </span>
            </div>
            </div>
        </div>
        </div>
    <?php endforeach; ?>
    </div>

    <!-- Add Modal -->
    <div id="addBinModal" class="hidden fixed inset-0 z-[60] flex items-center justify-center p-4 bg-gray-900/40 backdrop-blur-sm">
    <div class="bg-white w-full max-w-md rounded-[2.5rem] shadow-2xl p-8 relative animate-in zoom-in duration-300">
        <button onclick="document.getElementById('addBinModal').classList.add('hidden')" class="absolute top-6 right-6 p-2 hover:bg-gray-100 rounded-full transition">
        <i data-lucide="x" class="w-6 h-6 text-gray-400"></i>
        </button>
        
        <h2 class="text-2xl font-bold text-gray-800 mb-6">Add New Bin</h2>
        
        <form method="POST" class="space-y-4">
        <input type="hidden" name="action" value="add">
        
        <label class="block">
            <span class="text-xs font-bold text-gray-400 uppercase tracking-widest mb-1 block">Bin Name</span>
            <input name="name" required class="w-full p-4 rounded-xl border border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none transition bg-gray-50" placeholder="e.g. Library Main Entrance" />
        </label>
        
        <label class="block">
            <span class="text-xs font-bold text-gray-400 uppercase tracking-widest mb-1 block">Location Description</span>
            <input name="location" required class="w-full p-4 rounded-xl border border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none transition bg-gray-50" placeholder="e.g. North Side, Ground Floor" />
        </label>
        
        <div class="grid grid-cols-2 gap-4">
            <label class="block">
            <span class="text-xs font-bold text-gray-400 uppercase tracking-widest mb-1 block">Latitude</span>
            <input type="number" step="any" name="lat" class="w-full p-4 rounded-xl border border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none transition bg-gray-50" placeholder="0.00" />
            </label>
            <label class="block">
            <span class="text-xs font-bold text-gray-400 uppercase tracking-widest mb-1 block">Longitude</span>
            <input type="number" step="any" name="lng" class="w-full p-4 rounded-xl border border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none transition bg-gray-50" placeholder="0.00" />
            </label>
        </div>

        <label class="block">
            <span class="text-xs font-bold text-gray-400 uppercase tracking-widest mb-1 block">Bin Type</span>
            <select name="type" class="w-full p-4 rounded-xl border border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none transition bg-gray-50">
            <option value="general">General Recycling</option>
            <option value="e-waste">E-Waste Only</option>
            <option value="glass">Glass Only</option>
            <option value="paper">Paper Only</option>
            </select>
        </label>
        
        <button type="submit" class="w-full bg-primary text-white py-4 rounded-2xl font-bold hover:bg-dark-green transition shadow-lg mt-4">
            Deploy Bin
        </button>
        </form>
    </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
