<?php
require_once '../config.php';
require_once '../services/db.php';

// Start session if not started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: " . BASE_URL . "/login.php");
    exit;
}

$error = '';
$success = '';
$editingReward = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'add' || $action === 'edit') {
        $name = $_POST['name'] ?? '';
        $description = $_POST['description'] ?? '';
        $cost = intval($_POST['cost'] ?? 0);
        $stock = intval($_POST['stock'] ?? 0);
        $imagePath = null;

        if ($name && $cost > 0) {
            // Handle Image Upload
            if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
                $uploadDir = '../assets/uploads/rewards/';
                if (!is_dir($uploadDir)) {
                    mkdir($uploadDir, 0777, true);
                }
                
                $fileExt = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
                $allowed = ['jpg', 'jpeg', 'png', 'webp'];
                
                if (in_array($fileExt, $allowed)) {
                    $newFileName = uniqid('reward_') . '.' . $fileExt;
                    $destPath = $uploadDir . $newFileName;
                    
                    if (move_uploaded_file($_FILES['image']['tmp_name'], $destPath)) {
                        // Store relative path for portability
                        $imagePath = '/assets/uploads/rewards/' . $newFileName;
                    } else {
                         $error = "Failed to move uploaded file.";
                    }
                } else {
                    $error = "Invalid file type. Allowed: jpg, jpeg, png, webp.";
                }
            }

            if (!$error) {
                if ($action === 'add') {
                    $db->addReward($name, $description, $cost, $stock, $imagePath);
                    header("Location: manage-rewards.php?msg=added");
                    exit;
                } elseif ($action === 'edit') {
                    $id = $_POST['id'] ?? 0;
                    if ($id) {
                        $db->updateReward($id, $name, $description, $cost, $stock, $imagePath);
                        header("Location: manage-rewards.php?msg=updated");
                        exit;
                    }
                }
            }
        } else {
            $error = "Name and valid cost are required.";
        }
    } elseif ($action === 'toggle') {
        $id = $_POST['id'] ?? 0;
        if ($id) {
            $db->toggleReward($id);
            header("Location: manage-rewards.php?msg=toggled");
            exit;
        }
    } elseif ($action === 'delete') {
        $id = $_POST['id'] ?? 0;
        if ($id) {
            try {
                $db->deleteReward($id);
                // Redirect to prevent re-submission
                header("Location: manage-rewards.php?msg=deleted");
                exit;
            } catch (Exception $e) {
                $error = $e->getMessage();
            }
        }
    } elseif ($action === 'update') {
        $id = $_POST['id'] ?? '';
        $stock = intval($_POST['stock'] ?? 0);
        if ($id) {
            $db->updateRewardStock($id, $stock);
            header("Location: manage-rewards.php?msg=stock_updated");
            exit;
        }
    }
} elseif (isset($_GET['edit'])) {
    $id = intval($_GET['edit']);
    $editingReward = $db->getRewardById($id);
    if (!$editingReward) {
        $error = "Reward not found for editing.";
    }
}

// Handle messages from redirect
if (isset($_GET['msg'])) {
    if ($_GET['msg'] === 'added') $success = "Reward added successfully.";
    if ($_GET['msg'] === 'updated') $success = "Reward updated successfully.";
    if ($_GET['msg'] === 'deleted') $success = "Reward deleted successfully.";
    if ($_GET['msg'] === 'stock_updated') $success = "Stock updated.";
    if ($_GET['msg'] === 'toggled') $success = "Reward status updated.";
}

$rewards = $db->getRewards();

// NOW include the header which outputs HTML
require_once '../includes/header.php';
?>

<div class="max-w-7xl mx-auto space-y-8 pb-12">
    <div class="flex flex-col md:flex-row md:items-center justify-between gap-6">
    <div>
        <h1 class="text-3xl font-bold text-gray-800">Rewards Inventory</h1>
        <p class="text-gray-500">Manage catalog items, stock levels, and pricing.</p>
    </div>
    <button onclick="document.getElementById('addRewardModal').classList.remove('hidden')" class="bg-primary text-white px-6 py-3 rounded-2xl font-bold hover:bg-dark-green transition shadow-lg flex items-center gap-2">
        <i data-lucide="plus" class="w-5 h-5"></i> Add Item
    </button>
    </div>

    <?php if ($error): ?>
    <div class="bg-red-50 text-red-700 p-4 rounded-xl border border-red-100 flex items-center gap-2">
        <i data-lucide="alert-triangle" class="w-5 h-5"></i> <?= htmlspecialchars($error) ?>
    </div>
    <?php endif; ?>

    <?php if ($success): ?>
    <div class="bg-green-50 text-green-700 p-4 rounded-xl border border-green-100 flex items-center gap-2">
        <i data-lucide="check-circle" class="w-5 h-5"></i> <?= htmlspecialchars($success) ?>
    </div>
    <?php endif; ?>

    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
    <?php foreach ($rewards as $r): ?>
        <div class="bg-white rounded-[2rem] shadow-sm border border-gray-100 overflow-hidden flex flex-col group hover:shadow-xl transition-all">
        <div class="relative aspect-video overflow-hidden">
            <img 
            src="<?= !empty($r['image']) ? BASE_URL . htmlspecialchars($r['image']) : BASE_URL . "/assets/images/default-reward.png" ?>" 
            class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
            alt="<?= htmlspecialchars($r['name']) ?>"
            />
            <div class="absolute top-4 right-4 bg-white/90 backdrop-blur-sm px-3 py-1 rounded-full shadow-sm">
            <p class="text-primary font-bold text-xs"><?= $r['costPoints'] ?> pts</p>
            </div>
        </div>
        
        <div class="p-6 flex-1 flex flex-col">
            <div class="flex justify-between items-start mb-2">
            <h3 class="text-lg font-bold text-gray-800 leading-tight"><?= htmlspecialchars($r['name']) ?></h3>
            <div class="flex gap-1">
                <a href="?edit=<?= $r['id'] ?>" class="p-2 text-blue-500 hover:bg-blue-50 rounded-lg transition">
                    <i data-lucide="pencil" class="w-5 h-5"></i>
                </a>
                <button type="button" onclick="showConfirmModal(<?= $r['id'] ?>, 'delete')" class="p-2 text-red-500 hover:bg-red-50 rounded-lg transition" title="Delete">
                    <i data-lucide="trash-2" class="w-5 h-5"></i>
                </button>
                <button type="button" onclick="showConfirmModal(<?= $r['id'] ?>, <?= $r['active'] ? 'true' : 'false' ?>)" class="p-2 <?= $r['active'] ? 'text-green-500 hover:bg-green-50' : 'text-gray-400 hover:bg-gray-100' ?> rounded-lg transition" title="<?= $r['active'] ? 'Deactivate' : 'Activate' ?>">
                    <i data-lucide="<?= $r['active'] ? 'toggle-right' : 'toggle-left' ?>" class="w-6 h-6"></i>
                </button>
            </div>
            </div>
            <input type="hidden" name="action" value="update">
            <input type="hidden" name="id" value="<?= $r['id'] ?>">
            <div class="flex items-center justify-between gap-4">
                <span class="text-xs font-bold text-gray-400 uppercase tracking-widest">Stock</span>
                <div class="flex items-center gap-2">
                <input 
                    type="number" 
                    name="stock" 
                    value="<?= $r['stock'] ?>" 
                    class="w-20 p-2 text-center rounded-lg border border-gray-200 font-bold text-gray-800 focus:ring-2 focus:ring-primary/20 outline-none"
                    min="0"
                />
                <button type="submit" class="bg-gray-100 hover:bg-primary hover:text-white px-4 py-2 rounded-lg transition font-bold text-sm">
                    Save
                </button>
                </div>
            </div>
            </form>
        </div>
        </div>
    <?php endforeach; ?>
    </div>

    <!-- Add Modal -->
    <!-- Add/Edit Modal -->
    <div id="addRewardModal" class="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-gray-900/40 backdrop-blur-sm <?= $editingReward ? '' : 'hidden' ?>">
    <div class="bg-white w-full max-w-lg rounded-[2.5rem] shadow-2xl p-8 relative animate-in zoom-in duration-300">
        <button onclick="document.getElementById('addRewardModal').classList.add('hidden')" class="absolute top-6 right-6 p-2 hover:bg-gray-100 rounded-full transition">
        <i data-lucide="x" class="w-6 h-6 text-gray-400"></i>
        </button>
        
        <h2 class="text-2xl font-bold text-gray-800 mb-6"><?= $editingReward ? 'Edit Reward' : 'Add New Reward' ?></h2>
        
        <form method="POST" enctype="multipart/form-data" class="space-y-4">
        <input type="hidden" name="action" value="<?= $editingReward ? 'edit' : 'add' ?>">
        <?php if ($editingReward): ?>
            <input type="hidden" name="id" value="<?= $editingReward['id'] ?>">
        <?php endif; ?>
        
        <label class="block">
            <span class="text-xs font-bold text-gray-400 uppercase tracking-widest mb-1 block">Reward Name</span>
            <input type="text" name="name" required value="<?= $editingReward ? htmlspecialchars($editingReward['name']) : '' ?>" class="w-full p-4 rounded-xl border border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none transition bg-gray-50" placeholder="e.g. Eco T-Shirt" />
        </label>
        
        <label class="block">
            <span class="text-xs font-bold text-gray-400 uppercase tracking-widest mb-1 block">Description</span>
            <textarea name="description" required class="w-full p-4 rounded-xl border border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none transition bg-gray-50 min-h-[100px]" placeholder="Brief description..."><?= $editingReward ? htmlspecialchars($editingReward['description']) : '' ?></textarea>
        </label>
        
        <label class="block">
            <span class="text-xs font-bold text-gray-400 uppercase tracking-widest mb-1 block">Reward Image (Optional)</span>
            <?php if ($editingReward && !empty($editingReward['image'])): ?>
                <div class="mb-2">
                    <img src="<?= BASE_URL . htmlspecialchars($editingReward['image']) ?>" alt="Current" class="w-16 h-16 object-cover rounded-lg border border-gray-200">
                    <p class="text-xs text-gray-400 mt-1">Current image</p>
                </div>
            <?php endif; ?>
            <input type="file" name="image" accept="image/*" class="w-full p-4 rounded-xl border border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none transition bg-gray-50 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-primary/10 file:text-primary hover:file:bg-primary/20" />
        </label>
        
        <div class="grid grid-cols-2 gap-4">
            <label class="block">
            <span class="text-xs font-bold text-gray-400 uppercase tracking-widest mb-1 block">Point Cost</span>
            <input type="number" name="cost" required value="<?= $editingReward['costPoints'] ?? '' ?>" class="w-full p-4 rounded-xl border border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none transition bg-gray-50" placeholder="0" />
            </label>
            <label class="block">
            <span class="text-xs font-bold text-gray-400 uppercase tracking-widest mb-1 block">Initial Stock</span>
            <input type="number" name="stock" required value="<?= $editingReward['stock'] ?? '' ?>" class="w-full p-4 rounded-xl border border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none transition bg-gray-50" placeholder="0" />
            </label>
        </div>
        
        <div class="flex gap-3">
            <?php if ($editingReward): ?>
                <a href="manage-rewards.php" class="flex-1 bg-gray-100 text-gray-600 py-4 rounded-2xl font-bold text-lg hover:bg-gray-200 transition text-center">Cancel</a>
            <?php endif; ?>
            <button type="submit" class="flex-1 bg-primary text-white py-4 rounded-2xl font-bold text-lg hover:bg-dark-green transition shadow-lg shadow-primary/20 flex items-center justify-center gap-2">
                <i data-lucide="plus-circle" class="w-5 h-5"></i> <?= $editingReward ? 'Update Reward' : 'Add Reward' ?>
            </button>
        </div>
        </form>
    </div>
    </div>
    <!-- Confirmation Modal -->
    <div id="confirmModal" class="hidden fixed inset-0 z-[70] flex items-center justify-center p-4 bg-gray-900/40 backdrop-blur-sm">
        <div class="bg-white w-full max-w-sm rounded-[2rem] shadow-2xl p-6 relative animate-in zoom-in duration-300">
            <div class="w-16 h-16 bg-yellow-50 text-yellow-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <i data-lucide="alert-circle" class="w-8 h-8"></i>
            </div>
            <h3 class="text-xl font-bold text-gray-800 text-center mb-2">Are you sure?</h3>
            <p id="confirmMessage" class="text-gray-500 text-center mb-6">Do you really want to perform this action?</p>
            
            <div class="flex gap-3">
                <button onclick="closeConfirmModal()" class="flex-1 bg-gray-100 text-gray-600 py-3 rounded-xl font-bold hover:bg-gray-200 transition">
                    Cancel
                </button>
                <form method="POST" id="confirmForm" class="flex-1">
                    <input type="hidden" name="action" value="toggle">
                    <input type="hidden" name="id" id="confirmId">
                    <button type="submit" class="w-full bg-primary text-white py-3 rounded-xl font-bold hover:bg-dark-green transition shadow-lg shadow-primary/20">
                        Confirm
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
    function showConfirmModal(id, type) {
        const modal = document.getElementById('confirmModal');
        const message = document.getElementById('confirmMessage');
        const inputId = document.getElementById('confirmId');
        const form = document.getElementById('confirmForm');
        
        inputId.value = id;
        form.action.value = (type === 'delete') ? 'delete' : 'toggle';
        
        if (type === 'delete') {
            message.innerText = "This will permanently delete the reward if no one has redeemed it yet.";
        } else {
             // type is boolean true/false for active status
             message.innerText = type 
                ? "This will deactivate the reward. Students won't be able to see it." 
                : "This will activate the reward. It will satisfy student cravings!";
        }
            
        modal.classList.remove('hidden');
    }

    function closeConfirmModal() {
        document.getElementById('confirmModal').classList.add('hidden');
    }
</script>

<?php require_once '../includes/footer.php'; ?>
