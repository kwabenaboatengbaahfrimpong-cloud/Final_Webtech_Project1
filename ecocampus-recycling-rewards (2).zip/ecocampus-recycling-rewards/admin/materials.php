<?php
require_once '../includes/header.php';
require_once '../services/db.php';

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: " . BASE_URL . "/login.php");
    exit;
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'add') {
        $name = $_POST['name'] ?? '';
        $points = floatval($_POST['points'] ?? 0);
        $limit = floatval($_POST['daily_limit'] ?? 50);
        
        if ($name && $points > 0) {
            $db->addMaterial($name, $points, $limit);
            $success = "Material added successfully.";
        }
    } elseif ($action === 'edit') {
        $id = $_POST['id'] ?? 0;
        $name = $_POST['name'] ?? '';
        $points = floatval($_POST['points'] ?? 0);
        $limit = floatval($_POST['daily_limit'] ?? 50);
        
        if ($id && $name && $points > 0) {
            $db->updateMaterial($id, $name, $points, $limit);
            $success = "Material updated successfully.";
        }
    } elseif ($action === 'toggle') {
        $id = $_POST['id'] ?? '';
        if ($id) {
            $db->toggleMaterialStatus($id);
            $success = "Status updated.";
        }
    }
}

$materials = $db->getMaterials();
$editingMaterial = null;
if (isset($_GET['edit'])) {
    foreach ($materials as $m) {
        if ($m['id'] == $_GET['edit']) {
            $editingMaterial = $m;
            break;
        }
    }
}
?>

<div class="max-w-7xl mx-auto space-y-8 pb-12">
    <div class="flex flex-col md:flex-row md:items-center justify-between gap-6">
    <div>
        <h1 class="text-3xl font-bold text-gray-800">Materials Management</h1>
        <p class="text-gray-500">Configure recyclable types and their point values.</p>
    </div>
    <button onclick="document.getElementById('addMaterialModal').classList.remove('hidden')" class="bg-primary text-white px-6 py-3 rounded-2xl font-bold hover:bg-dark-green transition shadow-lg flex items-center gap-2">
        <i data-lucide="plus" class="w-5 h-5"></i> Add Material
    </button>
    </div>

    <?php if ($error): ?>
    <div class="bg-red-50 text-red-700 p-4 rounded-xl border border-red-100 flex items-center gap-2">
        <i data-lucide="alert-triangle" class="w-5 h-5"></i> <?= htmlspecialchars($error) ?>
    </div>
    <?php endif; ?>

    <?php if ($success): ?>
    <div class="bg-green-50 text-green-700 p-4 rounded-xl border border-green-100 flex items-center gap-2">
        <i data-lucide="check-circle" class="w-5 h-5"></i> <?= htmlspecialchars($success) ?>
    </div>
    <?php endif; ?>

    <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
    <?php foreach ($materials as $m): ?>
        <div class="bg-white rounded-[2rem] shadow-sm border border-gray-100 overflow-hidden group">
        <div class="p-8">
            <div class="flex justify-between items-start mb-6">
                <div class="bg-blue-50 p-4 rounded-2xl text-blue-500">
                    <i data-lucide="recycle" class="w-8 h-8"></i>
                </div>
                <div class="flex items-center gap-2">
                    <a href="?edit=<?= $m['id'] ?>" class="p-2 text-blue-500 hover:bg-blue-50 rounded-lg transition">
                        <i data-lucide="pencil" class="w-5 h-5"></i>
                    </a>
                    <form method="POST">
                        <input type="hidden" name="action" value="toggle">
                        <input type="hidden" name="id" value="<?= $m['id'] ?>">
                        <button type="submit" class="p-2 <?= $m['active'] ? 'text-green-500 hover:bg-green-50' : 'text-gray-400 hover:bg-gray-100' ?> rounded-lg transition" title="Toggle Status">
                            <i data-lucide="<?= $m['active'] ? 'toggle-right' : 'toggle-left' ?>" class="w-6 h-6"></i>
                        </button>
                    </form>
                </div>
            </div>
            
            <h3 class="text-xl font-bold text-gray-800 mb-2"><?= htmlspecialchars($m['name']) ?></h3>
            <div class="flex items-center gap-2 mt-2">
                <span class="text-sm font-bold text-primary"><?= $m['pointsPerKg'] ?> pts/kg</span>
                <span class="text-gray-300">•</span>
                <span class="text-sm text-gray-500">Limit: <?= $m['daily_limit'] ?? 50 ?>kg</span>
            </div>
            <div class="space-y-3">
            <div class="flex items-center justify-between text-sm">
                <span class="text-gray-500">Value</span>
                <span class="font-bold text-primary"><?= $m['pointsPerKg'] ?> pts/kg</span>
            </div>
            <div class="flex items-center justify-between text-sm">
                <span class="text-gray-500">CO2 Saved</span>
                <span class="font-bold text-gray-700"><?= $m['co2SavedPerKg'] ?> kg/kg</span>
            </div>
            <div class="flex items-center justify-between text-sm">
                <span class="text-gray-500">Status</span>
                <span class="font-bold <?= $m['active'] ? 'text-green-600' : 'text-gray-400' ?>">
                <?= $m['active'] ? 'Active' : 'Archived' ?>
                </span>
            </div>
            </div>
        </div>
        </div>
    <?php endforeach; ?>
    </div>

    <!-- Add Modal -->
    <div id="addMaterialModal" class="hidden fixed inset-0 z-[60] flex items-center justify-center p-4 bg-gray-900/40 backdrop-blur-sm">
    <div class="bg-white w-full max-w-md rounded-[2.5rem] shadow-2xl p-8 relative animate-in zoom-in duration-300">
        <button onclick="document.getElementById('addMaterialModal').classList.add('hidden')" class="absolute top-6 right-6 p-2 hover:bg-gray-100 rounded-full transition">
        <i data-lucide="x" class="w-6 h-6 text-gray-400"></i>
        </button>
        
        <h2 class="text-2xl font-bold text-gray-800 mb-6"><?= $editingMaterial ? 'Edit Material' : 'Add New Material' ?></h2>
        
        <form method="POST" class="space-y-4">
        <input type="hidden" name="action" value="<?= $editingMaterial ? 'edit' : 'add' ?>">
        <?php if ($editingMaterial): ?>
            <input type="hidden" name="id" value="<?= $editingMaterial['id'] ?>">
        <?php endif; ?>

        <label class="block">
            <span class="text-xs font-bold text-gray-400 uppercase tracking-widest mb-1 block">Material Name</span>
            <input type="text" name="name" required value="<?= htmlspecialchars($editingMaterial['name'] ?? '') ?>" class="w-full p-4 rounded-xl border border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none transition bg-gray-50" placeholder="e.g. Plastic, Glass" />
        </label>
        
        <div class="grid grid-cols-2 gap-4">
            <label class="block">
                <span class="text-xs font-bold text-gray-400 uppercase tracking-widest mb-1 block">Points per Kg</span>
                <input type="number" step="0.1" name="points" required value="<?= $editingMaterial['pointsPerKg'] ?? '' ?>" class="w-full p-4 rounded-xl border border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none transition bg-gray-50" placeholder="0.0" />
            </label>
             <label class="block">
                <span class="text-xs font-bold text-gray-400 uppercase tracking-widest mb-1 block">Daily Limit (kg)</span>
                <input type="number" step="0.1" name="daily_limit" required value="<?= $editingMaterial['daily_limit'] ?? 25 ?>" class="w-full p-4 rounded-xl border border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none transition bg-gray-50" min="15" />
            </label>
        </div>
        
        <div class="flex gap-3">
             <?php if ($editingMaterial): ?>
                <a href="materials.php" class="flex-1 bg-gray-100 text-gray-600 py-4 rounded-2xl font-bold text-lg hover:bg-gray-200 transition text-center">Cancel</a>
            <?php endif; ?>
            <button type="submit" class="flex-1 w-full bg-primary text-white py-4 rounded-2xl font-bold text-lg hover:bg-dark-green transition shadow-lg shadow-primary/20 flex items-center justify-center gap-2">
                <i data-lucide="plus-circle" class="w-5 h-5"></i> <?= $editingMaterial ? 'Update Material' : 'Add Material' ?>
            </button>
        </div>
        </form>
    </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
