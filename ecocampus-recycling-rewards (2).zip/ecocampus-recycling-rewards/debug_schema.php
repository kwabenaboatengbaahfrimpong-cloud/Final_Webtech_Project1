<?php
require_once 'services/db.php';
$pdo = getDBConnection();
$stmt = $pdo->query("SHOW CREATE TABLE users");
$row = $stmt->fetch(PDO::FETCH_ASSOC);
echo "Create Table SQL:\n" . $row['Create Table'] . "\n\n";

$users = $db->getUsers();
echo "All Users:\n";
foreach ($users as $u) {
    echo "ID: " . $u['id'] . " | Name: " . $u['name'] . " | Created: " . ($u['created_at'] ?? 'NULL') . "\n";
}
?>
