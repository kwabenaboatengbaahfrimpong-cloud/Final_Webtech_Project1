# EcoCampus Recycling 

EcoCampus is a web-based sustainability platform designed to incentivize recycling on university campuses. It gamifies the recycling process by allowing students to log their recycling activities, earn points based on material weight and type, and redeem those points for real-world rewards.

## Features

### For Students
*   **Interactive Dashboard**: View real-time stats, current points, and an AI-powered sustainability ticker.
*   **Log Recycling**: Easily submit recycling logs by selecting material type, bin location, and weight. Includes daily limit validation.
*   **Rewards Shop**: Browse and redeem exclusive campus rewards using earned points.
*   **Activity History**: Track the status of all submissions (pending, approved, rejected) and redemption requests.
*   **Leaderboard**: Compete with other students to see who is the top eco-champion.
*   **Profile Management**: Update contact details and view account summary.
*   **Support**: Built-in support form to contact administrators.

###  For Administrators
*   **Admin Command Center**: Overview of total students, pending actions, and system health.
*   **Submission Review**: Verify, approve, or reject student recycling logs with optional feedback notes.
*   **Redemption Fulfillment**: Manage and fulfill reward requests from students.
*   **Inventory Management**:
    *   **Rewards**: Add, edit, delete, and manage stock for rewards.
    *   **Materials**: Configure material types, points per kg, and daily limits.
    *   **Bins**: Manage recycling bin locations and status.

## Technology Stack

*   **Backend**: PHP (Vanilla, Object-Oriented style)
*   **Database**: MySQL
*   **Frontend**: HTML5, Tailwind CSS (via CDN)
*   **Icons**: Lucide Icons
*   **Typography**: 'Outfit' (Headings) & 'Inter' (Body) via Google Fonts

## Installation & Setup

### Prerequisites
*   **XAMPP** (or any PHP/MySQL development environment)
*   Web Browser

### Steps
1.  **Clone/Download**: Place the project folder `ecocampus-recycling-rewards` into your `htdocs` directory (e.g., `C:\xampp\htdocs\ecocampus-recycling-rewards`).
2.  **Database Setup**:
    *   Open phpMyAdmin (`http://localhost/phpmyadmin`).
    *   Create a new database named `ecocampus`.
    *   Import the provided SQL schema (not included in repo, ensure tables `users`, `materials`, `bins`, `rewards`, `submissions`, `redemptions`, `support_messages` are created).
3.  **Configuration**:
    *   The application uses `config.php` to automatically detect the `BASE_URL`. Ensure this file is present in the root.
    *   Database connection settings are in `config.php` (default: `localhost`, `root`, empty password, db `ecocampus`). Update if necessary.
4.  **Run**:
    *   Start Apache and MySQL modules in XAMPP.
    *   Navigate to `http://localhost/ecocampus-recycling-rewards/` in your browser.

## Project Structure

```
ecocampus-recycling-rewards/
├── admin/              # Admin dashboard and management pages
├── assets/             # CSS, images, and other static assets
├── includes/           # Reusable components (header, footer)
├── services/           # Backend logic (Database class, Auth)
├── student/            # Student-facing pages
├── config.php          # Global configuration
├── index.php           # Landing page
└── README.md           # Project documentation
```

## Accounts

*   **Student Role**: Sign up via the registration page.
*   **Admin Role**: Manually set `role = 'admin'` in the `users` database table for specific accounts.

## Visual Design
The application features a modern, eco-friendly design using a green and earth-tone color palette (`#4a7c59`, `#a98467`). It utilizes fully responsive layouts with `max-w-7xl` containers for optimal viewing on all devices.
