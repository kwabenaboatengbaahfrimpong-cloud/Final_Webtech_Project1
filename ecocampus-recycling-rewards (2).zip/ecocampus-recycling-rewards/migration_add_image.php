<?php
require_once 'services/db.php';
$pdo = getDBConnection();
try {
    $pdo->exec("ALTER TABLE rewards ADD COLUMN image VARCHAR(255) DEFAULT NULL AFTER description");
    echo "Successfully added image column to rewards table.\n";
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
?>
