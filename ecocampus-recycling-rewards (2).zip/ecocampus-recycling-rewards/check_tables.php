<?php
require_once 'services/db.php';
$pdo = getDBConnection();
$stmt = $pdo->query("SHOW TABLES");
print_r($stmt->fetchAll(PDO::FETCH_COLUMN));
?>
