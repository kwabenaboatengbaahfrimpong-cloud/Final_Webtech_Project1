<?php
require_once 'services/db.php';
session_start();

echo "<h1>Login Debugger</h1>";

echo "<h2>1. Session Status</h2>";
echo "Session ID: " . session_id() . "<br>";
if (isset($_SESSION['user'])) {
    echo "User is currently logged in via Session: <pre>" . print_r($_SESSION['user'], true) . "</pre>";
} else {
    echo "User is NOT logged in via Session.<br>";
}

echo "<h2>2. Database Connection</h2>";
try {
    $db = new Database();
    echo "Database initialized successfully.<br>";
} catch (Exception $e) {
    die("DB Init Failed: " . $e->getMessage());
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    echo "<h2>3. Login Attempt</h2>";
    $email = $_POST['email'];
    $password = $_POST['password'];
    
    echo "Attempting login for: " . htmlspecialchars($email) . "<br>";
    
    // Manual lookup to debug hash
    $pdo = getDBConnection();
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();
    
    if (!$user) {
        echo "<span style='color:red; font-size:1.2em; font-weight:bold;'>User Not Found in DB!</span><br>";
        echo "<p>Please click the <b>RED BUTTON</b> on the right to create this user.</p>";
    } else {
        echo "User found in DB. Role: " . $user['role'] . "<br>";
        echo "Stored Hash: " . substr($user['password_hash'], 0, 20) . "...<br>";
        
        if (password_verify($password, $user['password_hash'])) {
            echo "<span style='color:green'>Password Verification SUCCESS!</span><br>";
            $_SESSION['user'] = $user;
            echo "Session updated. <a href='index.php'>Go to Home</a> or <a href='admin/dashboard.php'>Go to Admin Dashboard</a>";
        } else {
            echo "<span style='color:red'>Password Verification FAILED!</span><br>"; 
            echo "Hash in DB does not match provided password.<br>";
        }
    }
}
?>


// Handle Reset Action
if (isset($_POST['reset_password'])) {
    echo "<h2>4. Password Reset / User Creation</h2>";
    $email = 'admin@ecocampus.com';
    $newPass = 'admin1234';
    
    try {
        $pdo = getDBConnection();
        // Check if exists first for clarity
        $check = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $check->execute([$email]);
        
        if ($check->rowCount() > 0) {
            // Update
            $hash = password_hash($newPass, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("UPDATE users SET password_hash = ?, role = 'admin' WHERE email = ?");
            $stmt->execute([$hash, $email]);
             echo "<div style='background:lightgreen; padding:10px; border:1px solid green;'>Password Successfully Reset to 'admin1234'</div><br>";
        } else {
             // Create
             $db->register('Admin User', $email, '0000000000', $newPass);
             // Ensure role is admin
             $pdo->prepare("UPDATE users SET role = 'admin' WHERE email = ?")->execute([$email]);
             echo "<div style='background:lightgreen; padding:10px; border:1px solid green;'>User Created with password 'admin1234'</div><br>";
        }
    } catch (Exception $e) {
        echo "<div style='background:pink; padding:10px; border:1px solid red; color:red;'>Error creating user: " . $e->getMessage() . "</div>";
        echo "<h3>Manual SQL Fallback</h3>";
        echo "<p>If the button failed, run this SQL in phpMyAdmin:</p>";
        
        $manualHash = password_hash('admin1234', PASSWORD_DEFAULT);
        echo "<textarea style='width:100%; height:100px; font-family:monospace;'>";
        echo "DELETE FROM users WHERE email = 'admin@ecocampus.com';\n";
        echo "INSERT INTO users (name, email, phone, password_hash, role) VALUES ('Admin', 'admin@ecocampus.com', '1234', '$manualHash', 'admin');";
        echo "</textarea>";
    }
}
?>

<hr>
<div style="display:flex; gap:20px; flex-wrap:wrap;">
    <form method="POST" style="background:#eee; padding:20px; flex:1; min-width:300px;">
        <h3>1. Test Login</h3>
        Email: <input type="email" name="email" value="admin@ecocampus.com"><br><br>
        Password: <input type="text" name="password" value="admin1234"><br><br>
        <button type="submit">Test Login</button>
    </form>
    
    <form method="POST" style="background:#ffd; padding:20px; flex:1; min-width:300px; border:1px solid orange;">
        <h3>2. Emergency Fix</h3>
        <p><b>User Not Found? Login Failed?</b><br>Click this button to Create the Admin User or Reset the Password.</p>
        <input type="hidden" name="reset_password" value="1">
        <button type="submit" style="background:red; color:white; padding:15px; font-weight:bold; cursor:pointer; font-size:1.2em; width:100%;">CREATE USER / RESET PASSWORD</button>
    </form>
</div>
