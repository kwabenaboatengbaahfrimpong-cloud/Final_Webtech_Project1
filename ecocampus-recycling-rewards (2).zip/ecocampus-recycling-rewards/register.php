<?php
require_once 'services/db.php';
session_start();

$error = '';
$name = '';
$email = '';
$phone = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'] ?? '';
    $email = $_POST['email'] ?? '';
    $phone = $_POST['phone'] ?? '';
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['confirm'] ?? '';

    if ($password !== $confirm) {
        $error = 'Passwords do not match';
    } elseif (strlen($password) < 8) {
        $error = 'Password must be at least 8 characters long';
    } else {
        try {
            $user = $db->register($name, $email, $phone, $password);
            // Auto login or redirect to login? Store says just register.
            // React app navigated to /login.
            header("Location: " . BASE_URL . "/login.php");
            exit;
        } catch (Exception $e) {
            $error = $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register | EcoCampus</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/style.css">
    <script src="https://unpkg.com/lucide@latest"></script>
</head>
<body class="bg-cream">
    <div class="min-h-screen flex items-center justify-center p-4">
        <div class="max-w-md w-full bg-white rounded-3xl shadow-2xl overflow-hidden my-8">
            <div class="bg-primary p-8 text-white text-center">
                <div class="inline-flex items-center justify-center w-16 h-16 bg-white/20 rounded-full mb-4">
                    <i data-lucide="leaf" class="w-10 h-10"></i>
                </div>
                <h2 class="text-3xl font-bold">Join EcoCampus</h2>
                <p class="text-white/80 mt-2">Start earning from your efforts</p>
            </div>
            
            <form method="POST" class="p-8 space-y-4" onsubmit="return validateForm()">
                <?php if ($error): ?>
                <div class="p-3 bg-red-50 text-red-600 rounded-xl text-sm border border-red-100"><?= htmlspecialchars($error) ?></div>
                <?php endif; ?>

                <div class="space-y-1">
                    <label class="text-xs font-bold text-gray-500 uppercase tracking-wider ml-1">Full Name</label>
                    <div class="relative">
                        <i data-lucide="user" class="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400"></i>
                        <input 
                            type="text" 
                            name="name"
                            required
                            value="<?= htmlspecialchars($name) ?>"
                            placeholder="Barbara Hutton"
                            class="w-full pl-12 pr-4 py-3 rounded-xl border border-gray-200 outline-none transition"
                        />
                    </div>
                </div>

                <div class="space-y-1">
                    <label class="text-xs font-bold text-gray-500 uppercase tracking-wider ml-1">University Email</label>
                    <div class="relative">
                        <i data-lucide="mail" class="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400"></i>
                         <input 
                            type="email" 
                            name="email"
                            required
                            value="<?= htmlspecialchars($email) ?>"
                            placeholder="student@university.edu"
                            class="w-full pl-12 pr-4 py-3 rounded-xl border border-gray-200 outline-none transition"
                        />
                    </div>
                </div>

                <div class="space-y-1">
                    <label class="text-xs font-bold text-gray-500 uppercase tracking-wider ml-1">Phone Number (Optional)</label>
                    <div class="relative">
                        <i data-lucide="phone" class="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400"></i>
                         <input 
                            type="tel"
                            name="phone"
                            value="<?= htmlspecialchars($phone) ?>"
                            placeholder="+1 234 567 890"
                            class="w-full pl-12 pr-4 py-3 rounded-xl border border-gray-200 outline-none transition"
                        />
                    </div>
                </div>

                <div class="grid grid-cols-2 gap-4">
                    <div class="space-y-1">
                        <label class="text-xs font-bold text-gray-500 uppercase tracking-wider ml-1">Password</label>
                        <div class="relative">
                            <i data-lucide="lock" class="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400"></i>
                            <input 
                                type="password" 
                                name="password"
                                id="password"
                                required
                                class="w-full pl-10 pr-10 py-3 rounded-xl border border-gray-200 text-sm outline-none transition"
                            />
                            <button type="button" onclick="togglePassword('password')" class="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-primary">
                                <i data-lucide="eye" class="w-4 h-4"></i>
                            </button>
                        </div>
                    </div>
                    <div class="space-y-1">
                        <label class="text-xs font-bold text-gray-500 uppercase tracking-wider ml-1">Confirm</label>
                        <div class="relative">
                            <i data-lucide="lock" class="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400"></i>
                             <input 
                                type="password" 
                                name="confirm"
                                id="confirm"
                                required
                                class="w-full pl-10 pr-10 py-3 rounded-xl border border-gray-200 text-sm outline-none transition"
                            />
                            <button type="button" onclick="togglePassword('confirm')" class="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-primary">
                                <i data-lucide="eye" class="w-4 h-4"></i>
                            </button>
                        </div>
                    </div>
                </div>

                <div class="text-xs text-gray-500 pl-1">
                    Password must be at least 8 characters.
                </div>

                <div class="flex items-center gap-2 pt-2">
                    <i data-lucide="shield-check" class="w-5 h-5 text-primary"></i>
                    <p class="text-xs text-gray-500">Only student roles can register publicly.</p>
                </div>

                <button 
                    type="submit"
                    class="w-full bg-primary text-white py-4 rounded-xl font-bold text-lg hover:bg-dark-green transition shadow-lg"
                >
                    Create Account
                </button>

                <div class="text-center pt-2">
                    <p class="text-gray-500">Already a member? <a href="<?= BASE_URL ?>/login.php" class="text-primary font-bold hover:underline">Sign In</a></p>
                </div>
            </form>
        </div>
    </div>
    <script>
        lucide.createIcons();

        function togglePassword(id) {
            const input = document.getElementById(id);
            if (input.type === 'password') {
                input.type = 'text';
            } else {
                input.type = 'password';
            }
        }

        function validateForm() {
            const password = document.getElementById('password').value;
            const confirm = document.getElementById('confirm').value;

            if (password.length < 8) {
                alert("Password must be at least 8 characters long.");
                return false;
            }



            if (password !== confirm) {
                alert("Passwords do not match.");
                return false;
            }

            return true;
        }
    </script>
    <script>
        lucide.createIcons();
    </script>
</body>
</html>
