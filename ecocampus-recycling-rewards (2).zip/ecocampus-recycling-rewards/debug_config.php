<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'config.php';

echo "<h1>Environment Debug</h1>";

echo "<h2>Paths</h2>";
echo "<b>__DIR__ (Project Root):</b> " . str_replace('\\', '/', __DIR__) . "<br>";
echo "<b>DOCUMENT_ROOT:</b> " . str_replace('\\', '/', $_SERVER['DOCUMENT_ROOT']) . "<br>";
echo "<b>Calculated BASE_URL:</b> '" . BASE_URL . "' <br>";
echo "(This should be the path visible in your browser URL bar, e.g. if you are at example.com/myproject/debug_config.php, it should be /myproject)<br>";

echo "<h2>Database Configuration</h2>";
echo "<b>Host:</b> " . DB_HOST . "<br>";
echo "<b>DB Name:</b> " . DB_NAME . "<br>";
echo "<b>User:</b> " . DB_USER . "<br>";

echo "<h2>Connection Test</h2>";
try {
    $pdo = getDBConnection();
    echo "<span style='color:green; font-weight:bold;'>Database Connection Successful!</span><br>";
    
    echo "<h3>Tables:</h3>";
    $stmt = $pdo->query("SHOW TABLES");
    $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
    if (empty($tables)) {
        echo "<span style='color:orange;'>Connected, but no tables found. Please import database_schema.sql</span>";
    } else {
        echo "<ul>";
        foreach ($tables as $t) {
            echo "<li>$t</li>";
        }
        echo "</ul>";
    }
} catch (Exception $e) {
    echo "<span style='color:red; font-weight:bold;'>Connection Failed:</span> " . $e->getMessage();
}
?>
