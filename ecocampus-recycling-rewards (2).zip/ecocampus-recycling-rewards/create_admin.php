<?php
require_once 'services/db.php';

$name = "Admin User";
$email = "admin@ecocampus.com";
$password = "admin1234";

echo "<h1>Create Admin User</h1>";

try {
    $db = new Database();
    
    // Check if exists
    $pdo = getDBConnection();
    $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->execute([$email]);
    
    if ($stmt->fetch()) {
        // Update existing
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $update = $pdo->prepare("UPDATE users SET password_hash = ?, role = 'admin' WHERE email = ?");
        $update->execute([$hash, $email]);
        echo "<p style='color:green'>User $email already exists. Password updated to '$password'.</p>";
    } else {
        // Create new
        $db->register($name, $email, '0000000000', $password);
        
        // Force role to admin (register defaults to student)
        $update = $pdo->prepare("UPDATE users SET role = 'admin' WHERE email = ?");
        $update->execute([$email]);
        
        echo "<p style='color:green'>Admin user created successfully!</p>";
        echo "Email: $email<br>";
        echo "Password: $password<br>";
    }
    
} catch (Exception $e) {
    echo "<p style='color:red'>Error: " . $e->getMessage() . "</p>";
}
?>
