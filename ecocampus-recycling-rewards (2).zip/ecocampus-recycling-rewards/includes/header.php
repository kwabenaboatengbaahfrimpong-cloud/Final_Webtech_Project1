<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/../config.php';
// Helper to check active path
function isActive($path) {
    $current = $_SERVER['PHP_SELF'];
    return strpos($current, $path) !== false ? 'bg-white/20 text-white' : 'hover:bg-white/10 text-white/80 hover:text-white';
}

$user = $_SESSION['user'] ?? null;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EcoCampus | Recycle & Earn</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Outfit:wght@400;500;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/style.css">
</head>
<body>

<div class="min-h-screen flex flex-col md:flex-row">
    <!-- Mobile Nav -->
    <div class="md:hidden bg-primary p-4 flex justify-between items-center text-white sticky top-0 z-50">
        <a href="<?= BASE_URL ?>/" class="flex items-center gap-2 text-xl font-bold">
            <i data-lucide="leaf" class="w-8 h-8"></i> EcoCampus
        </a>
        <button id="sidebar-toggle">
            <i data-lucide="menu"></i>
        </button>
    </div>

    <?php if ($user): ?>
    <!-- Sidebar -->
    <aside id="sidebar" class="fixed md:sticky top-0 h-screen w-64 bg-primary text-white z-40 transition-transform duration-300 transform -translate-x-full md:translate-x-0">
        <div class="p-6 hidden md:flex items-center gap-3 border-b border-white/10 mb-6">
            <i data-lucide="leaf" class="w-10 h-10 text-white"></i>
            <span class="text-2xl font-bold tracking-tight">EcoCampus</span>
        </div>

        <nav class="px-4 space-y-2">
            <?php if ($user['role'] === 'admin'): ?>
                <a href="<?= BASE_URL ?>/admin/dashboard.php" class="flex items-center gap-3 px-4 py-3 rounded-lg transition-colors <?= isActive('dashboard') ?>">
                    <i data-lucide="layout-dashboard" class="w-5 h-5 text-xl"></i> <span class="font-medium">Dashboard</span>
                </a>
                <a href="<?= BASE_URL ?>/admin/submissions.php" class="flex items-center gap-3 px-4 py-3 rounded-lg transition-colors <?= isActive('submissions') ?>">
                    <i class="ph-bold ph-check-square-offset w-5 h-5 text-xl"></i> <span class="font-medium">Submissions</span>
                </a>
                <a href="<?= BASE_URL ?>/admin/materials.php" class="flex items-center gap-3 px-4 py-3 rounded-lg transition-colors <?= isActive('materials') ?>">
                    <i data-lucide="recycle" class="w-5 h-5 text-xl"></i> <span class="font-medium">Materials</span>
                </a>
                <a href="<?= BASE_URL ?>/admin/bins.php" class="flex items-center gap-3 px-4 py-3 rounded-lg transition-colors <?= isActive('bins') ?>">
                    <i data-lucide="trash-2" class="w-5 h-5 text-xl"></i> <span class="font-medium">Bin Locations</span>
                </a>
                <a href="<?= BASE_URL ?>/admin/manage-rewards.php" class="flex items-center gap-3 px-4 py-3 rounded-lg transition-colors <?= isActive('manage-rewards') ?>">
                    <i class="ph-bold ph-gift w-5 h-5 text-xl"></i> <span class="font-medium">Manage Rewards</span>
                </a>
                <a href="<?= BASE_URL ?>/admin/redemptions.php" class="flex items-center gap-3 px-4 py-3 rounded-lg transition-colors <?= isActive('redemptions') ?>">
                    <i data-lucide="package" class="w-5 h-5 text-xl"></i> <span class="font-medium">Redemptions</span>
                </a>
            <?php else: ?>
                <a href="<?= BASE_URL ?>/student/dashboard.php" class="flex items-center gap-3 px-4 py-3 rounded-lg transition-colors <?= isActive('dashboard') ?>">
                    <i data-lucide="home" class="w-5 h-5 text-xl"></i> <span class="font-medium">Dashboard</span>
                </a>
                <a href="<?= BASE_URL ?>/student/submit.php" class="flex items-center gap-3 px-4 py-3 rounded-lg transition-colors <?= isActive('submit') ?>">
                    <i data-lucide="files" class="w-5 h-5 text-xl"></i> <span class="font-medium">Log Recycling</span>
                </a>
                <a href="<?= BASE_URL ?>/student/history.php" class="flex items-center gap-3 px-4 py-3 rounded-lg transition-colors <?= isActive('history') ?>">
                    <i data-lucide="history" class="w-5 h-5 text-xl"></i> <span class="font-medium">History</span>
                </a>
                <a href="<?= BASE_URL ?>/student/rewards.php" class="flex items-center gap-3 px-4 py-3 rounded-lg transition-colors <?= isActive('rewards') ?>">
                    <i class="ph-bold ph-gift w-5 h-5 text-xl"></i> <span class="font-medium">Rewards</span>
                </a>
                <a href="<?= BASE_URL ?>/student/leaderboard.php" class="flex items-center gap-3 px-4 py-3 rounded-lg transition-colors <?= isActive('leaderboard') ?>">
                    <i data-lucide="trophy" class="w-5 h-5 text-xl"></i> <span class="font-medium">Leaderboard</span>
                </a>
                <a href="<?= BASE_URL ?>/student/profile.php" class="flex items-center gap-3 px-4 py-3 rounded-lg transition-colors <?= isActive('profile') ?>">
                    <i data-lucide="user" class="w-5 h-5 text-xl"></i> <span class="font-medium">Profile</span>
                </a>
                <a href="<?= BASE_URL ?>/student/help.php" class="flex items-center gap-3 px-4 py-3 rounded-lg transition-colors <?= isActive('help') ?>">
                    <i data-lucide="help-circle" class="w-5 h-5 text-xl"></i> <span class="font-medium">Need Assistant</span>
                </a>
            <?php endif; ?>
        </nav>

        <div class="absolute bottom-0 w-full p-4 border-t border-white/10">
            <a href="<?= BASE_URL ?>/logout.php" class="flex items-center gap-3 w-full px-4 py-3 text-white/80 hover:text-white hover:bg-orange-600 rounded-lg transition-all">
                <i data-lucide="log-out" class="w-5 h-5"></i>
                <span class="font-medium">Logout</span>
            </a>
        </div>
    </aside>
    <?php endif; ?>

    <!-- Content -->
    <main class="flex-1 overflow-y-auto p-4 md:p-8">
