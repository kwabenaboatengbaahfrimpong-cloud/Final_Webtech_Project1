    </main>
</div>
<script>
    lucide.createIcons();
    
    // Mobile Sidebar Toggle
    const btn = document.getElementById('sidebar-toggle');
    const sidebar = document.getElementById('sidebar');
    
    if(btn && sidebar) {
        btn.addEventListener('click', () => {
             sidebar.classList.toggle('-translate-x-full');
        });
    }
</script>
</body>
</html>
